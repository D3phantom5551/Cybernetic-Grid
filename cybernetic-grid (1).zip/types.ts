
export type Player = 'BLUE' | 'RED';
export type PowerUpType = 'FIRE' | 'SHIELD' | 'LIGHTNING' | 'HEAL' | 'CRIT' | 'NONE';
export type IconType = string; // Changed from union to string to support A-Z
export type BackgroundType = 'DEFAULT' | 'CYBER_CITY' | 'MATRIX' | 'NEBULA' | 'DEEP_SPACE';

export interface GridCell {
  id: string;
  x: number;
  y: number;
  owner: Player | null;
  powerUp: PowerUpType;
  powerUpLife?: number; // Turns remaining before vanishing
}

export interface PlayerState {
  hp: number;
  shield: boolean;
  critActive: boolean;
  color: string;
  name: string;
  icon: IconType;
}

export interface DamageIndicator {
  id: string;
  value: number;
  x: number;
  y: number;
  color: string;
}

export interface GameState {
  board: GridCell[][];
  players: Record<Player, PlayerState>;
  currentPlayer: Player;
  isGameOver: boolean;
  isSuddenDeath: boolean;
  winner: Player | null;
  turnTimer: number;
  matchTimer: number; // Overall match duration in seconds
  stageColor: string;
  stageLevel: number;
}

export const NEON_COLORS = [
  // Standard (Always Unlocked)
  { name: 'Cyan', hex: '#22d3ee', locked: false },
  { name: 'Fuchsia', hex: '#e879f9', locked: false },
  { name: 'Lime', hex: '#a3e635', locked: false },
  { name: 'Amber', hex: '#fbbf24', locked: false },
  { name: 'Rose', hex: '#fb7185', locked: false },
  { name: 'Indigo', hex: '#818cf8', locked: false },
  { name: 'Yellow', hex: '#facc15', locked: false },
  { name: 'Emerald', hex: '#34d399', locked: false },
  
  // Elite (Unlockable via Arcade)
  { name: 'Crimson', hex: '#dc2626', locked: true },
  { name: 'Deep Blue', hex: '#1d4ed8', locked: true },
  { name: 'Toxic Green', hex: '#65a30d', locked: true },
  { name: 'Royal Purple', hex: '#7e22ce', locked: true },
  { name: 'Hot Pink', hex: '#db2777', locked: true },
  { name: 'Burnt Orange', hex: '#ea580c', locked: true },
  { name: 'Ice White', hex: '#f8fafc', locked: true },
  { name: 'Void Black', hex: '#0f172a', locked: true },
  { name: 'Electric Violet', hex: '#8b5cf6', locked: true },
  { name: 'Mint', hex: '#6ee7b7', locked: true },
  { name: 'Gold', hex: '#fcd34d', locked: true },
  { name: 'Silver', hex: '#94a3b8', locked: true }
];

export const BACKGROUNDS: { id: BackgroundType; name: string; css: string; unlockLevel: number }[] = [
  { id: 'DEFAULT', name: 'Grid Core', css: 'bg-[#020617]', unlockLevel: 0 },
  { id: 'DEEP_SPACE', name: 'Deep Void', css: 'bg-slate-950', unlockLevel: 5 },
  { id: 'CYBER_CITY', name: 'Neon City', css: 'bg-indigo-950', unlockLevel: 10 },
  { id: 'MATRIX', name: 'Data Stream', css: 'bg-green-950', unlockLevel: 20 },
  { id: 'NEBULA', name: 'Cosmic Dust', css: 'bg-fuchsia-950', unlockLevel: 30 },
];
