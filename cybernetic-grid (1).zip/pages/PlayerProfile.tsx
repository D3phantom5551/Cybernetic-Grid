
import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, User, Shield, Zap, TrendingUp, Award, Flame, Target, Heart } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const MOCK_DATA = [
  { name: 'Mon', wins: 4 },
  { name: 'Tue', wins: 7 },
  { name: 'Wed', wins: 5 },
  { name: 'Thu', wins: 12 },
  { name: 'Fri', wins: 8 },
  { name: 'Sat', wins: 15 },
  { name: 'Sun', wins: 10 },
];

const POWER_UP_STATS = [
  { name: 'FIRE', count: 42, icon: Flame, color: '#fb923c' },
  { name: 'SHIELD', count: 28, icon: Shield, color: '#60a5fa' },
  { name: 'CRIT', count: 15, icon: Target, color: '#c026d3' },
];

const AI_RIVALS = [
  { name: 'NEXUS_V1 (EASY)', wins: 24, losses: 2 },
  { name: 'NEXUS_V5 (MED)', wins: 12, losses: 8 },
  { name: 'NEXUS_V9 (HARD)', wins: 3, losses: 15 },
];

const PlayerProfile: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-950 p-6 md:p-12 text-slate-200">
      <div className="max-w-5xl mx-auto">
        <button onClick={() => navigate('/')} className="mb-12 flex items-center gap-2 text-slate-500 hover:text-white transition-colors font-mono">
          <ChevronLeft /> RETURN_TO_ROOT
        </button>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Info */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1 space-y-8"
          >
            <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl text-center relative overflow-hidden group">
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-cyan-500 to-purple-500" />
              <div className="w-24 h-24 bg-slate-800 rounded-full mx-auto mb-4 flex items-center justify-center border-2 border-cyan-500/50">
                <User size={48} className="text-cyan-400" />
              </div>
              <h2 className="text-2xl font-black text-white">OPERATOR_42</h2>
              <p className="text-cyan-400 font-mono text-sm">LEVEL 14 ARCHITECT</p>
              
              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-800/50 rounded-xl">
                  <div className="text-[10px] text-slate-500 uppercase">Win Rate</div>
                  <div className="text-lg font-bold text-white">64%</div>
                </div>
                <div className="p-3 bg-slate-800/50 rounded-xl">
                  <div className="text-[10px] text-slate-500 uppercase">Rank</div>
                  <div className="text-lg font-bold text-amber-400">GOLD</div>
                </div>
              </div>
            </div>

            <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl">
              <h3 className="text-sm font-bold text-slate-500 mb-6 flex items-center gap-2">
                <Award size={16} /> RECENT ACHIEVEMENTS
              </h3>
              <div className="space-y-4">
                {[
                  { title: "Neural Surge", desc: "Win in under 10 turns", icon: <Zap className="text-cyan-400" /> },
                  { title: "Grid Warden", desc: "Maintain 100% control for 3 turns", icon: <Shield className="text-purple-400" /> },
                  { title: "AI Crusher", desc: "Defeat Nexus-9 on Hard", icon: <TrendingUp className="text-amber-400" /> }
                ].map((ach, idx) => (
                  <div key={idx} className="flex items-center gap-4 p-3 bg-slate-800/30 rounded-xl border border-slate-800">
                    <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center">
                      {ach.icon}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{ach.title}</div>
                      <div className="text-[10px] text-slate-500">{ach.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Detailed Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2 space-y-8"
          >
            <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl min-h-[400px]">
              <h3 className="text-lg font-black text-white mb-8">DOMINANCE PERFORMANCE</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={MOCK_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                      itemStyle={{ color: '#22d3ee' }}
                    />
                    <Bar dataKey="wins" fill="#22d3ee" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
                {/* Most Used Power Ups */}
                <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl">
                    <h3 className="text-sm font-black text-slate-500 uppercase tracking-widest mb-6">Combat Protocol Favorites</h3>
                    <div className="space-y-4">
                        {POWER_UP_STATS.map((stat) => (
                            <div key={stat.name} className="flex items-center gap-4">
                                <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                                    <stat.icon size={16} style={{ color: stat.color }} />
                                </div>
                                <div className="flex-1">
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="text-xs font-bold text-slate-300">{stat.name}</span>
                                        <span className="text-xs text-slate-500">{stat.count} uses</span>
                                    </div>
                                    <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                        <div 
                                            className="h-full rounded-full" 
                                            style={{ width: `${(stat.count / 50) * 100}%`, backgroundColor: stat.color }}
                                        />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* AI Rivals */}
                <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl">
                    <h3 className="text-sm font-black text-slate-500 uppercase tracking-widest mb-6">Threat Analysis</h3>
                    <div className="space-y-3">
                        {AI_RIVALS.map((ai) => (
                            <div key={ai.name} className="flex items-center justify-between p-3 bg-slate-950/50 rounded-xl border border-slate-800">
                                <span className="text-xs font-bold text-white">{ai.name}</span>
                                <div className="flex gap-3 text-[10px] font-mono">
                                    <span className="text-green-400">W:{ai.wins}</span>
                                    <span className="text-red-400">L:{ai.losses}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default PlayerProfile;
