
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChevronLeft, RotateCcw, Swords, Flame, Wifi, Clock, Menu, Activity, Home, Play, Smartphone, Palette, Terminal, AlertCircle, ChevronRight, Lock } from 'lucide-react';
import GameGrid from '../components/GameGrid';
import GameHUD from '../components/GameHUD';
import PauseMenu from '../components/PauseMenu';
import { InGameTutorial } from '../components/InGameTutorial';
import { GridCell, Player, GameState, NEON_COLORS, PowerUpType, DamageIndicator, IconType, BACKGROUNDS } from '../types';

const GRID_SIZE = 8;
const INITIAL_HP = 200;
const MATCH_TIME = 360; // 6 minutes
const MAX_POWER_UPS = 8;
const POWER_UP_POOL: PowerUpType[] = ['FIRE', 'SHIELD', 'LIGHTNING', 'HEAL', 'CRIT'];
const POWER_UP_LIFETIME = 6;

const VSMode: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const initialSuddenDeath = location.state?.suddenDeath || false;
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [stageIndex, setStageIndex] = useState(0);
  const [damageIndicators, setDamageIndicators] = useState<DamageIndicator[]>([]);
  const [suddenDeathModifier, setSuddenDeathModifier] = useState(initialSuddenDeath);
  const [turnDuration, setTurnDuration] = useState(6); // Default 6s

  // Player Config State
  const [p1Config, setP1Config] = useState({ name: 'OP_ALPHA', color: NEON_COLORS[0].hex, icon: 'X' as IconType });
  const [p2Config, setP2Config] = useState({ name: 'OP_BETA', color: NEON_COLORS[1].hex, icon: 'O' as IconType });
  
  // Background State
  const [currentBgCss, setCurrentBgCss] = useState('bg-[#020617]');

  // Bluetooth Mock State
  const [isScanning, setIsScanning] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'IDLE' | 'SCANNING' | 'CONNECTED'>('IDLE');

  // Unlocked content
  const [unlockedColors, setUnlockedColors] = useState<string[]>([]);
  const [unlockedIcons, setUnlockedIcons] = useState<string[]>([]);

  useEffect(() => {
    // Load config from local storage
    const savedP1 = localStorage.getItem('player1_config');
    const savedP2 = localStorage.getItem('player2_config');
    const savedTimer = localStorage.getItem('vs_turn_timer');
    const savedBgId = localStorage.getItem('selected_background') || 'DEFAULT';
    const savedColors = localStorage.getItem('unlocked_colors');
    const savedIcons = localStorage.getItem('unlocked_icons');

    const bg = BACKGROUNDS.find(b => b.id === savedBgId);
    if (bg) setCurrentBgCss(bg.css);

    if (savedColors) setUnlockedColors(JSON.parse(savedColors));
    if (savedIcons) setUnlockedIcons(JSON.parse(savedIcons));

    let loadedP1 = savedP1 ? JSON.parse(savedP1) : { name: 'OP_ALPHA', color: NEON_COLORS[0].hex, icon: 'X' };
    let loadedP2 = savedP2 ? JSON.parse(savedP2) : { name: 'OP_BETA', color: NEON_COLORS[1].hex, icon: 'O' };

    // Conflict Resolution Logic (Backup in case Settings didn't catch it)
    if (loadedP1.color === loadedP2.color) {
        const availableColors = NEON_COLORS.filter(c => c.hex !== loadedP1.color);
        loadedP2.color = availableColors[0]?.hex || NEON_COLORS[1].hex;
    }
    if (loadedP1.icon === loadedP2.icon) {
        const icons: IconType[] = ['X', 'O', '1', '0', 'S'];
        loadedP2.icon = icons.find(i => i !== loadedP1.icon) || 'O';
    }

    setP1Config(loadedP1);
    setP2Config(loadedP2);
    if (savedTimer) setTurnDuration(parseInt(savedTimer, 10));
  }, []);

  const handleSimulateBluetooth = () => {
      setConnectionStatus('SCANNING');
      setIsScanning(true);
      setTimeout(() => {
          setIsScanning(false);
          setConnectionStatus('CONNECTED');
      }, 3000);
  };

  const createInitialBoard = (): GridCell[][] => {
    const board = Array(GRID_SIZE).fill(null).map((_, y) => 
      Array(GRID_SIZE).fill(null).map((_, x) => ({ 
        id: `${x}-${y}-${Math.random()}`, x, y, owner: null, powerUp: 'NONE' as PowerUpType, powerUpLife: 0
      }))
    );
    for(let i = 0; i < 6; i++) {
        const rx = Math.floor(Math.random() * GRID_SIZE);
        const ry = Math.floor(Math.random() * GRID_SIZE);
        board[ry][rx].powerUp = POWER_UP_POOL[Math.floor(Math.random() * POWER_UP_POOL.length)];
        board[ry][rx].powerUpLife = POWER_UP_LIFETIME;
    }
    return board;
  };

  const [gameState, setGameState] = useState<GameState>({
    board: createInitialBoard(),
    players: {
      BLUE: { hp: INITIAL_HP, shield: false, critActive: false, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
      RED: { hp: INITIAL_HP, shield: false, critActive: false, color: p2Config.color, name: p2Config.name, icon: p2Config.icon }
    },
    currentPlayer: 'BLUE',
    isGameOver: false,
    isSuddenDeath: suddenDeathModifier,
    winner: null,
    turnTimer: turnDuration,
    matchTimer: suddenDeathModifier ? 0 : MATCH_TIME,
    stageColor: NEON_COLORS[Math.floor(Math.random() * 8)].hex, // Random standard color
    stageLevel: 1
  });

  // Update game state when config loads (if game hasn't started essentially)
  useEffect(() => {
    if (!isPlaying) {
        setGameState(prev => ({
            ...prev,
            turnTimer: turnDuration,
            players: {
                BLUE: { ...prev.players.BLUE, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
                RED: { ...prev.players.RED, color: p2Config.color, name: p2Config.name, icon: p2Config.icon }
            }
        }));
    }
  }, [p1Config, p2Config, turnDuration, isPlaying]);

  // Handle Match End (Stats update)
  useEffect(() => {
      if (gameState.isGameOver) {
          const matches = parseInt(localStorage.getItem('matches_played') || '0', 10);
          localStorage.setItem('matches_played', (matches + 1).toString());
      }
  }, [gameState.isGameOver]);

  const timerRef = useRef<number | null>(null);
  const matchTimerRef = useRef<number | null>(null);
  const suddenDeathRef = useRef<number | null>(null);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (isPaused) return;
    setGameState(prev => ({ ...prev, turnTimer: turnDuration }));
    
    timerRef.current = window.setInterval(() => {
      setGameState(prev => {
        if (prev.turnTimer <= 0) {
          return { ...prev, currentPlayer: prev.currentPlayer === 'BLUE' ? 'RED' : 'BLUE', turnTimer: turnDuration };
        }
        return { ...prev, turnTimer: prev.turnTimer - 1 };
      });
    }, 1000);
  }, [isPaused, turnDuration]);

  // Cycle Configuration for Setup Screen
  const cycleColor = (player: 'P1' | 'P2', direction: 'prev' | 'next') => {
      const current = player === 'P1' ? p1Config.color : p2Config.color;
      const other = player === 'P1' ? p2Config.color : p1Config.color;
      
      const availableColors = NEON_COLORS.filter(c => !c.locked || unlockedColors.includes(c.hex));
      let currentIndex = availableColors.findIndex(c => c.hex === current);
      
      let nextIndex = direction === 'next' 
        ? (currentIndex + 1) % availableColors.length 
        : (currentIndex - 1 + availableColors.length) % availableColors.length;
      
      // Skip collision
      if (availableColors[nextIndex].hex === other) {
          nextIndex = direction === 'next'
            ? (nextIndex + 1) % availableColors.length
            : (nextIndex - 1 + availableColors.length) % availableColors.length;
      }

      if (player === 'P1') {
          setP1Config(prev => ({ ...prev, color: availableColors[nextIndex].hex }));
      } else {
          setP2Config(prev => ({ ...prev, color: availableColors[nextIndex].hex }));
      }
  };

  const cycleIcon = (player: 'P1' | 'P2', direction: 'prev' | 'next') => {
      const current = player === 'P1' ? p1Config.icon : p2Config.icon;
      const other = player === 'P1' ? p2Config.icon : p1Config.icon;
      const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');
      const BASE_ICONS = ['X', 'O', '1', '0', 'S'];
      
      let availableIcons = [...BASE_ICONS];
      if (unlockedIcons) {
          availableIcons = [...availableIcons, ...unlockedIcons];
      }
      
      availableIcons = Array.from(new Set(availableIcons));

      let currentIndex = availableIcons.indexOf(current);
      if (currentIndex === -1) currentIndex = 0; // Fallback

      let nextIndex = direction === 'next'
        ? (currentIndex + 1) % availableIcons.length
        : (currentIndex - 1 + availableIcons.length) % availableIcons.length;
      
      // Skip collision
      if (availableIcons[nextIndex] === other) {
          nextIndex = direction === 'next'
            ? (nextIndex + 1) % availableIcons.length
            : (nextIndex - 1 + availableIcons.length) % availableIcons.length;
      }

      if (player === 'P1') {
          setP1Config(prev => ({ ...prev, icon: availableIcons[nextIndex] }));
      } else {
          setP2Config(prev => ({ ...prev, icon: availableIcons[nextIndex] }));
      }
  };

  const handleRestart = () => {
    // Standard restart for rematch button
    setGameState({
      board: createInitialBoard(),
      players: {
        BLUE: { hp: INITIAL_HP, shield: false, critActive: false, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
        RED: { hp: INITIAL_HP, shield: false, critActive: false, color: p2Config.color, name: p2Config.name, icon: p2Config.icon }
      },
      currentPlayer: 'BLUE',
      isGameOver: false,
      isSuddenDeath: suddenDeathModifier,
      winner: null,
      turnTimer: turnDuration,
      matchTimer: suddenDeathModifier ? 0 : MATCH_TIME,
      stageColor: NEON_COLORS[Math.floor(Math.random() * 8)].hex,
      stageLevel: 1
    });
    setIsPaused(false);
  };

  const handleForfeit = () => {
      const loser = gameState.currentPlayer;
      const winner = loser === 'BLUE' ? 'RED' : 'BLUE';

      setGameState(prev => ({
          ...prev,
          isGameOver: true,
          winner: winner
      }));
      setIsPaused(false);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isPlaying && !gameState.isGameOver) setIsPaused(p => !p);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isPlaying, gameState.isGameOver]);

  useEffect(() => {
    if (isPlaying && !gameState.isGameOver && !gameState.isSuddenDeath && !isPaused) {
      matchTimerRef.current = window.setInterval(() => {
        setGameState(prev => {
          if (prev.matchTimer <= 1) {
            clearInterval(matchTimerRef.current!);
            return { ...prev, matchTimer: 0, isSuddenDeath: true };
          }
          return { ...prev, matchTimer: prev.matchTimer - 1 };
        });
      }, 1000);
    }
    return () => { if (matchTimerRef.current) clearInterval(matchTimerRef.current); };
  }, [isPlaying, gameState.isGameOver, gameState.isSuddenDeath, isPaused]);

  useEffect(() => {
    if (isPlaying && !gameState.isGameOver && !gameState.isSuddenDeath && !isPaused) {
      startTimer();
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isPlaying, gameState.isGameOver, gameState.currentPlayer, gameState.isSuddenDeath, startTimer, isPaused]);

  useEffect(() => {
    if (gameState.isSuddenDeath && !gameState.isGameOver && !isPaused) {
      suddenDeathRef.current = window.setInterval(() => {
        setGameState(prev => {
          const newPlayers = { ...prev.players };
          newPlayers.BLUE.hp = Math.max(0, newPlayers.BLUE.hp - 1);
          newPlayers.RED.hp = Math.max(0, newPlayers.RED.hp - 1);
          let winner: Player | null = null;
          let isGameOver = false;
          if (newPlayers.BLUE.hp <= 0 && newPlayers.RED.hp <= 0) {
            winner = prev.players.BLUE.hp > prev.players.RED.hp ? 'BLUE' : 'RED';
            isGameOver = true;
          } else if (newPlayers.BLUE.hp <= 0) { 
            winner = 'RED'; isGameOver = true; 
          } else if (newPlayers.RED.hp <= 0) { 
            winner = 'BLUE'; isGameOver = true; 
          }
          return { ...prev, players: newPlayers, winner, isGameOver };
        });
      }, 2000); // 1 LP per 2 seconds
    }
    return () => { if (suddenDeathRef.current) clearInterval(suddenDeathRef.current); };
  }, [gameState.isSuddenDeath, gameState.isGameOver, isPaused]);

  const addDamageIndicator = (value: number, x: number, y: number, color: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setDamageIndicators(prev => [...prev, { id, value, x, y, color }]);
    setTimeout(() => {
      setDamageIndicators(prev => prev.filter(di => di.id !== id));
    }, 1000);
  };

  const handleCellClick = (x: number, y: number) => {
    if (!isPlaying || gameState.isGameOver || gameState.board[y][x].owner || isPaused) return;
    
    const currentPlayer = gameState.currentPlayer;
    const opponent = currentPlayer === 'BLUE' ? 'RED' : 'BLUE';
    
    setGameState(prev => {
      let newBoard: GridCell[][] = JSON.parse(JSON.stringify(prev.board));
      const newPlayers = JSON.parse(JSON.stringify(prev.players));
      const cell = newBoard[y][x];
      cell.owner = currentPlayer;

      let damage = 20;
      const matchedCells: {x: number, y: number}[] = [];

      const checkMatch = (dx: number, dy: number) => {
        const line = [{x, y}];
        let nx = x - dx, ny = y - dy;
        while(nx >= 0 && nx < GRID_SIZE && ny >= 0 && ny < GRID_SIZE && newBoard[ny][nx].owner === currentPlayer) {
          line.push({x: nx, y: ny}); nx -= dx; ny -= dy;
        }
        nx = x + dx; ny = y + dy;
        while(nx >= 0 && nx < GRID_SIZE && ny >= 0 && ny < GRID_SIZE && newBoard[ny][nx].owner === currentPlayer) {
          line.push({x: nx, y: ny}); nx += dx; ny += dy;
        }
        return line.length >= 3 ? line : null;
      };

      const matches = [checkMatch(1, 0), checkMatch(0, 1), checkMatch(1, 1), checkMatch(1,-1)];
      matches.forEach(m => m && matchedCells.push(...m));

      if (matchedCells.length > 0) {
        const uniqueMatches = Array.from(new Set(matchedCells.map(c => `${c.x},${c.y}`)))
          .map(s => {
            const [mx, my] = s.split(',').map(Number);
            return {x: mx, y: my};
          });

        uniqueMatches.forEach(p => {
          const pu = newBoard[p.y][p.x].powerUp;
          if (pu === 'FIRE') damage += 25;
          if (pu === 'LIGHTNING') damage += 15;
          if (pu === 'HEAL') newPlayers[currentPlayer].hp = Math.min(200, newPlayers[currentPlayer].hp + 20);
          if (pu === 'SHIELD') newPlayers[currentPlayer].shield = true;
          if (pu === 'CRIT') newPlayers[currentPlayer].critActive = true;
          newBoard[p.y][p.x].owner = null;
          newBoard[p.y][p.x].powerUp = 'NONE';
          newBoard[p.y][p.x].powerUpLife = 0;
        });

        if (newPlayers[currentPlayer].critActive) { damage *= 2; newPlayers[currentPlayer].critActive = false; }
        if (newPlayers[opponent].shield) { newPlayers[opponent].shield = false; damage = 0; }
        newPlayers[opponent].hp = Math.max(0, newPlayers[opponent].hp - damage);
        if (damage > 0) addDamageIndicator(damage, x, y, prev.players[currentPlayer].color);
      }

      newBoard = newBoard.map(row => row.map(c => {
        if (c.powerUp !== 'NONE' && !c.owner) {
          const newLife = (c.powerUpLife || 0) - 1;
          if (newLife <= 0) return { ...c, powerUp: 'NONE' as PowerUpType, powerUpLife: 0 };
          return { ...c, powerUpLife: newLife };
        }
        return c;
      }));

      let activePowerUps = 0;
      const emptyCells: {x: number, y: number}[] = [];
      newBoard.forEach(row => row.forEach(c => {
        if (c.powerUp !== 'NONE') activePowerUps++;
        if (c.powerUp === 'NONE' && !c.owner) emptyCells.push({ x: c.x, y: c.y });
      }));

      if (activePowerUps < MAX_POWER_UPS && emptyCells.length > 0) {
        const countToSpawn = Math.min(1 + Math.floor(Math.random() * 2), MAX_POWER_UPS - activePowerUps);
        for(let i = 0; i < countToSpawn; i++) {
            if (emptyCells.length === 0) break;
            const idx = Math.floor(Math.random() * emptyCells.length);
            const { x: sx, y: sy } = emptyCells.splice(idx, 1)[0];
            newBoard[sy][sx].powerUp = POWER_UP_POOL[Math.floor(Math.random() * POWER_UP_POOL.length)];
            newBoard[sy][sx].powerUpLife = POWER_UP_LIFETIME;
        }
      }

      const isBoardFull = newBoard.every((row: GridCell[]) => row.every((c: GridCell) => c.owner !== null));
      let isGameOver = newPlayers.BLUE.hp <= 0 || newPlayers.RED.hp <= 0;
      let winner: Player | null = isGameOver ? (newPlayers.BLUE.hp <= 0 ? 'RED' : 'BLUE') : null;
      let isSuddenDeath = prev.isSuddenDeath || (isBoardFull && !isGameOver);

      return {
        ...prev,
        board: newBoard,
        players: newPlayers,
        currentPlayer: opponent,
        isSuddenDeath,
        isGameOver,
        winner,
        turnTimer: turnDuration
      };
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isPlaying) {
    return (
      <div className={`min-h-screen transition-colors duration-1000 ${suddenDeathModifier ? 'bg-[#0a0202]' : currentBgCss} p-8 flex flex-col items-center justify-center font-mono relative overflow-hidden`}>
        <div className="absolute inset-0 opacity-10 pointer-events-none grid-bg" />
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="max-w-3xl w-full space-y-12 relative z-10 bg-slate-900/40 p-12 rounded-[40px] border border-white/5 backdrop-blur-3xl shimmer-effect">
           <div className="text-center">
             <h1 className="text-5xl font-black italic text-white mb-2 tracking-tighter" style={{ textShadow: '0 0 20px rgba(255,255,255,0.3)' }}>ARENA_CONFIG</h1>
             <p className="text-[10px] text-cyan-500 uppercase tracking-[0.5em] font-bold flex items-center justify-center gap-2">
                <Wifi size={12} className="animate-pulse" /> Neural_LAN_Active
             </p>
           </div>

           <div className="grid grid-cols-2 gap-12">
             {/* P1 Config Mini */}
             <div className="space-y-6">
                 <div className="flex items-center gap-2">
                   <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: p1Config.color, boxShadow: `0 0 10px ${p1Config.color}` }} />
                   <h3 className="text-sm font-black italic tracking-widest text-white uppercase">{p1Config.name}</h3>
                 </div>
                 
                 {/* Icon Selector */}
                 <div className="flex items-center justify-between bg-slate-950/50 rounded-xl p-3 border border-white/5">
                     <button onClick={() => cycleIcon('P1', 'prev')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronLeft size={16}/></button>
                     <div className="flex flex-col items-center">
                         <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">ICON</span>
                         <span className="text-2xl font-black text-white">{p1Config.icon}</span>
                     </div>
                     <button onClick={() => cycleIcon('P1', 'next')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronRight size={16}/></button>
                 </div>

                 {/* Color Selector */}
                 <div className="flex items-center justify-between bg-slate-950/50 rounded-xl p-3 border border-white/5">
                     <button onClick={() => cycleColor('P1', 'prev')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronLeft size={16}/></button>
                     <div className="flex flex-col items-center">
                         <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">COLOR</span>
                         <div className="w-8 h-8 rounded-full border-2 border-white shadow-[0_0_15px_currentColor]" style={{ backgroundColor: p1Config.color, color: p1Config.color }} />
                     </div>
                     <button onClick={() => cycleColor('P1', 'next')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronRight size={16}/></button>
                 </div>
             </div>

             {/* P2 Config Mini */}
             <div className="space-y-6">
                 <div className="flex items-center gap-2">
                   <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: p2Config.color, boxShadow: `0 0 10px ${p2Config.color}` }} />
                   <h3 className="text-sm font-black italic tracking-widest text-white uppercase">{p2Config.name}</h3>
                 </div>

                 {/* Icon Selector */}
                 <div className="flex items-center justify-between bg-slate-950/50 rounded-xl p-3 border border-white/5">
                     <button onClick={() => cycleIcon('P2', 'prev')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronLeft size={16}/></button>
                     <div className="flex flex-col items-center">
                         <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">ICON</span>
                         <span className="text-2xl font-black text-white">{p2Config.icon}</span>
                     </div>
                     <button onClick={() => cycleIcon('P2', 'next')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronRight size={16}/></button>
                 </div>

                 {/* Color Selector */}
                 <div className="flex items-center justify-between bg-slate-950/50 rounded-xl p-3 border border-white/5">
                     <button onClick={() => cycleColor('P2', 'prev')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronLeft size={16}/></button>
                     <div className="flex flex-col items-center">
                         <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">COLOR</span>
                         <div className="w-8 h-8 rounded-full border-2 border-white shadow-[0_0_15px_currentColor]" style={{ backgroundColor: p2Config.color, color: p2Config.color }} />
                     </div>
                     <button onClick={() => cycleColor('P2', 'next')} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><ChevronRight size={16}/></button>
                 </div>
             </div>
           </div>

           <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950/50 rounded-2xl border border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Activity className={`w-5 h-5 ${suddenDeathModifier ? 'text-red-500' : 'text-slate-500'}`} />
                        <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Sudden Death</span>
                    </div>
                    <button 
                        onClick={() => setSuddenDeathModifier(!suddenDeathModifier)}
                        className={`text-[9px] font-black px-4 py-1.5 rounded-lg border transition-all ${suddenDeathModifier ? 'bg-red-600/20 border-red-500 text-red-400 shadow-[0_0_10px_rgba(239,68,68,0.2)]' : 'bg-slate-800 border-white/5 text-slate-500'}`}
                    >
                        {suddenDeathModifier ? 'ENABLED' : 'DISABLED'}
                    </button>
                </div>

                {/* Bluetooth / Network Play Button */}
                <button
                    onClick={handleSimulateBluetooth}
                    disabled={connectionStatus === 'CONNECTED'}
                    className={`p-4 rounded-2xl border flex items-center justify-between transition-all ${connectionStatus === 'CONNECTED' ? 'bg-green-500/10 border-green-500 text-green-400' : 'bg-slate-950/50 border-white/5 hover:bg-blue-500/10 hover:border-blue-500 text-slate-300'}`}
                >
                    <div className="flex items-center gap-3">
                        <Smartphone size={20} className={connectionStatus === 'SCANNING' ? 'animate-pulse' : ''} />
                        <span className="text-[10px] font-black uppercase tracking-widest">
                            {connectionStatus === 'IDLE' && 'Connect Device (BT)'}
                            {connectionStatus === 'SCANNING' && 'Scanning...'}
                            {connectionStatus === 'CONNECTED' && 'Device Linked'}
                        </span>
                    </div>
                    <Wifi size={16} className={connectionStatus === 'CONNECTED' ? 'text-green-400' : 'text-slate-600'} />
                </button>
           </div>

           <button 
             onClick={() => {
               setGameState(prev => ({
                 ...prev,
                 isSuddenDeath: suddenDeathModifier,
                 matchTimer: suddenDeathModifier ? 0 : MATCH_TIME,
                 players: {
                   BLUE: { ...prev.players.BLUE, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
                   RED: { ...prev.players.RED, color: p2Config.color, name: p2Config.name, icon: p2Config.icon }
                 }
               }));
               setIsPlaying(true);
             }}
             className={`w-full py-6 font-black italic text-2xl rounded-3xl transition-all shadow-lg shimmer-effect ${suddenDeathModifier ? 'bg-red-600 text-white hover:bg-white hover:text-red-600 shadow-red-500/20' : 'bg-white text-slate-950 hover:bg-cyan-400 shadow-cyan-500/20'}`}
           >
             ENGAGE_PROTOCOL
           </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${currentBgCss} p-4 md:p-8 font-mono relative overflow-hidden transition-all duration-1000`}>
      <div className="absolute inset-0 opacity-10 pointer-events-none grid-bg" />
      <PauseMenu isOpen={isPaused} onClose={() => setIsPaused(false)} onRestart={handleRestart} />
      
      {/* HUD Bar */}
      <div className="fixed top-4 md:top-8 inset-x-0 px-4 md:px-8 flex flex-nowrap justify-between items-center z-50 w-full gap-2">
        <button onClick={() => setIsPaused(true)} className="flex-shrink-0 p-2 md:p-3 bg-slate-900/50 border border-white/5 rounded-xl text-slate-500 hover:text-white transition-all flex items-center gap-2">
          <Menu size={18} /> <span className="hidden md:inline font-black text-[10px] uppercase tracking-widest">PAUSE</span>
        </button>

        <div className="flex-shrink flex flex-col items-center mx-1 md:mx-4 overflow-hidden">
             <div className="flex items-center gap-2 md:gap-4 px-2 md:px-6 py-1.5 md:py-2 bg-slate-900/80 border border-white/5 rounded-full backdrop-blur-md">
                <div className="flex flex-col items-center border-r border-white/10 pr-2 md:pr-4">
                    <span className="text-[6px] md:text-[8px] text-slate-500 uppercase tracking-widest">SYNC</span>
                    <motion.span key={gameState.turnTimer} className={`text-sm md:text-2xl font-black italic ${gameState.turnTimer <= 2 ? 'text-red-500 animate-pulse' : 'text-white'}`}>0{gameState.turnTimer}</motion.span>
                </div>
                <div className="flex flex-col items-center pl-2 md:pl-4">
                    <span className="text-[6px] md:text-[8px] text-slate-500 uppercase tracking-widest">CORE</span>
                    <div className="flex items-center gap-1 md:gap-2">
                        <Clock size={10} className={gameState.matchTimer < 60 ? 'text-red-500 animate-pulse' : 'text-cyan-400'} />
                        <span className={`text-sm md:text-xl font-black italic ${gameState.matchTimer < 60 ? 'text-red-500' : 'text-cyan-400'}`}>{formatTime(gameState.matchTimer)}</span>
                    </div>
                </div>
             </div>
        </div>

        <button 
            onClick={handleForfeit} 
            className="flex-shrink-0 p-2 md:p-3 bg-red-950/30 border border-red-500/20 rounded-2xl text-red-500 hover:text-white hover:bg-red-600 transition-all group"
            title="FORFEIT MATCH"
        >
          <AlertCircle size={18} className="group-hover:rotate-180 transition-transform duration-500" />
        </button>
      </div>

      {/* Health Bars Overlayed in Corners */}
      <div className="fixed top-20 left-2 md:top-24 md:left-8 z-40 pointer-events-none">
        <GameHUD player={gameState.players.BLUE} side="left" isActive={gameState.currentPlayer === 'BLUE'} isSuddenDeath={gameState.isSuddenDeath} />
      </div>
      <div className="fixed top-20 right-2 md:top-24 md:right-8 z-40 pointer-events-none text-right">
        <GameHUD player={gameState.players.RED} side="right" isActive={gameState.currentPlayer === 'RED'} isSuddenDeath={gameState.isSuddenDeath} />
      </div>

      <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
        <AnimatePresence>
          {damageIndicators.map(di => (
            <motion.div
              key={di.id}
              initial={{ opacity: 0, y: 0, scale: 0.5 }}
              animate={{ opacity: 1, y: -100, scale: 1.5 }}
              exit={{ opacity: 0 }}
              className="absolute font-black text-2xl drop-shadow-[0_0_10px_rgba(0,0,0,0.5)]"
              style={{ 
                left: `${(di.x / GRID_SIZE) * 100}%`, 
                top: `${(di.y / GRID_SIZE) * 100}%`,
                color: di.color,
                textShadow: `0 0 10px ${di.color}`
              }}
            >
              -{di.value}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {gameState.isSuddenDeath && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 pointer-events-none z-0">
            <div className="absolute bottom-0 inset-x-0 h-[60vh] bg-gradient-to-t from-red-600/30 to-transparent" />
            
            {[...Array(6)].map((_, i) => (
              <motion.div 
                key={`flame-${i}`}
                animate={{ 
                  y: [0, -20, 0], 
                  scaleY: [1, 1.3, 1], 
                  scaleX: [1, 0.9, 1.1, 1],
                  opacity: [0.15, 0.35, 0.2] 
                }} 
                transition={{ 
                  duration: 1.5 + Math.random(), 
                  repeat: Infinity, 
                  delay: Math.random() * 2 
                }} 
                className="absolute text-red-600 blur-[2px]"
                style={{ 
                  bottom: `-${100 + Math.random() * 50}px`, 
                  left: `${(i * 20) - 10}%`,
                  zIndex: 0
                }}
              >
                <Flame size={400 + Math.random() * 400} />
              </motion.div>
            ))}

            <motion.div 
              animate={{ opacity: [0.1, 0.3, 0.1] }}
              transition={{ duration: 0.1, repeat: Infinity }}
              className="absolute inset-0 border-[30px] border-red-600/10 pointer-events-none" 
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto flex flex-col h-full gap-4 md:gap-8 relative z-10 pt-28 md:pt-32">
        <div className="w-full max-w-[550px] mx-auto flex-1 flex flex-col justify-center">
            <GameGrid 
              board={gameState.board} 
              onCellClick={handleCellClick} 
              currentPlayer={gameState.currentPlayer} 
              playerColors={{ BLUE: gameState.players.BLUE.color, RED: gameState.players.RED.color }}
              playerIcons={{ BLUE: gameState.players.BLUE.icon, RED: gameState.players.RED.icon }}
              stageColor={gameState.isSuddenDeath ? '#ef4444' : gameState.stageColor}
            />
        </div>

        <div className="mt-auto text-center py-4">
          <AnimatePresence mode="wait">
            {gameState.isSuddenDeath ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }} 
                animate={{ opacity: 1, scale: 1 }} 
                className="inline-flex items-center gap-2 px-6 md:px-8 py-2 md:py-3 bg-red-600/20 border-2 border-red-500 rounded-full shadow-[0_0_30px_rgba(220,38,38,0.5)]"
              >
                <Flame size={16} className="text-red-500 animate-bounce" />
                <span className="text-red-400 text-[8px] md:text-xs font-black uppercase tracking-[0.2em] flex items-center gap-1">
                  SUDDEN_DEATH_ENGAGED
                </span>
              </motion.div>
            ) : (
               <span className="text-[7px] md:text-[10px] text-slate-700 font-black tracking-[0.5em] md:tracking-[1em] uppercase opacity-40">Neural_Bridge_Active // Sector_30_Secured</span>
            )}
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {gameState.isGameOver && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 backdrop-blur-2xl p-4 shimmer-effect">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-900/10 to-transparent opacity-30" />
            
            <motion.div 
              initial={{ scale: 0.8, opacity: 0, y: 50 }} 
              animate={{ scale: 1, opacity: 1, y: 0 }} 
              className="text-center space-y-6 md:space-y-12 relative z-10"
            >
              <motion.div
                animate={{ rotate: [0, -5, 5, 0], scale: [1, 1.1, 1] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <Swords size={60} className="mx-auto text-white md:w-32 md:h-32 mb-4 drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]" />
              </motion.div>

              <div>
                <h2 className="text-4xl md:text-8xl font-black italic text-white tracking-tighter uppercase mb-2" style={{ textShadow: '0 0 40px rgba(255,255,255,0.5)' }}>Neural_Dominance</h2>
                <p className="text-2xl md:text-4xl font-black uppercase tracking-[0.3em] italic" style={{ 
                  color: gameState.players[gameState.winner!].color, 
                  textShadow: `0 0 20px ${gameState.players[gameState.winner!].color}, 0 0 40px ${gameState.players[gameState.winner!].color}` 
                }}>
                  {gameState.players[gameState.winner!].name} Dominates
                </p>
              </div>

              <div className="flex flex-col md:flex-row gap-4 md:gap-8 justify-center items-center w-full max-w-2xl mx-auto">
                <button 
                  onClick={handleRestart} 
                  className="w-full md:flex-1 px-8 py-6 bg-white text-slate-950 font-black italic text-lg md:text-2xl rounded-2xl md:rounded-3xl hover:bg-cyan-400 transition-all uppercase flex items-center justify-center gap-3 shadow-[0_0_30px_rgba(255,255,255,0.2)] group"
                >
                  <Play className="group-hover:translate-x-1 transition-transform" /> REMATCH_PROTOCOL
                </button>
                <button 
                  onClick={() => navigate('/')} 
                  className="w-full md:flex-1 px-8 py-6 bg-slate-900/50 border-2 border-white/20 text-white font-black italic text-lg md:text-2xl rounded-2xl md:rounded-3xl hover:border-white hover:bg-slate-800 transition-all uppercase flex items-center justify-center gap-3 group"
                >
                  <Home className="group-hover:-translate-y-1 transition-transform" /> HOME_BASE
                </button>
              </div>

              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold opacity-50">Match_ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default VSMode;
