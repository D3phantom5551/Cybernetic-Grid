
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, RotateCcw, Home, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PauseMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onRestart: () => void;
}

const PauseMenu: React.FC<PauseMenuProps> = ({ isOpen, onClose, onRestart }) => {
  const navigate = useNavigate();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-xl p-4"
        >
          <motion.div 
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="w-full max-w-sm bg-slate-900 border-2 border-white/10 rounded-[40px] p-8 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden shimmer-effect"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50" />
            
            <div className="text-center mb-8">
              <h2 className="text-3xl font-black italic text-white tracking-tighter uppercase mb-1">Paused</h2>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em]">Protocol_Suspended</p>
            </div>

            <div className="space-y-4">
              <button 
                onClick={onClose}
                className="w-full py-5 bg-white text-slate-950 font-black italic text-lg rounded-2xl hover:bg-cyan-400 transition-all flex items-center justify-center gap-3 group shadow-[0_0_20px_rgba(255,255,255,0.1)]"
              >
                <Play className="group-hover:translate-x-1 transition-transform" /> RESUME_SESSION
              </button>

              <button 
                onClick={() => { onRestart(); onClose(); }}
                className="w-full py-5 bg-slate-800 text-white font-black italic text-lg rounded-2xl hover:bg-slate-700 transition-all flex items-center justify-center gap-3 border border-white/5"
              >
                <RotateCcw size={20} /> RESTART_MATCH
              </button>

              <button 
                onClick={() => navigate('/')}
                className="w-full py-5 bg-slate-950/50 text-slate-400 font-black italic text-lg rounded-2xl hover:text-white hover:bg-red-950/20 hover:border-red-500/50 transition-all flex items-center justify-center gap-3 border border-white/5"
              >
                <Home size={20} /> ABORT_TO_BASE
              </button>
            </div>

            <button 
              onClick={onClose}
              className="absolute top-6 right-6 text-slate-600 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PauseMenu;
