
import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Volume2, VolumeX, Shield, Terminal, Upload, Music, CheckCircle2, User, Lock, Edit2, Palette, Clock, Image as ImageIcon, Smartphone, Ban } from 'lucide-react';
import { NEON_COLORS, BACKGROUNDS, IconType } from '../types';

interface SettingsMenuProps {
  isOpen: boolean;
  onClose: () => void;
  musicEnabled: boolean;
  onMusicToggle: (val: boolean) => void;
  onCustomAudio?: (file: File) => void;
  customAudioActive?: boolean;
}

const SettingsMenu: React.FC<SettingsMenuProps> = ({ isOpen, onClose, musicEnabled, onMusicToggle, onCustomAudio, customAudioActive }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'SYSTEM' | 'P1' | 'P2'>('SYSTEM');
  const [arcadeLevelMax, setArcadeLevelMax] = useState(0);
  const [matchesPlayed, setMatchesPlayed] = useState(0);
  const [unlockedColors, setUnlockedColors] = useState<string[]>([]);
  const [unlockedIcons, setUnlockedIcons] = useState<string[]>([]);

  // Local State for customization (synced with localStorage)
  const [p1Name, setP1Name] = useState('OP_ALPHA');
  const [p2Name, setP2Name] = useState('OP_BETA');
  const [p1Color, setP1Color] = useState(NEON_COLORS[0].hex);
  const [p2Color, setP2Color] = useState(NEON_COLORS[1].hex);
  const [p1Icon, setP1Icon] = useState<IconType>('X');
  const [p2Icon, setP2Icon] = useState<IconType>('O');
  
  // VS Timer State
  const [vsTimer, setVsTimer] = useState(6);
  // Background State
  const [selectedBg, setSelectedBg] = useState('DEFAULT');

  const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');
  const BASE_ICONS = ['X', 'O', '1', '0', 'S'];
  const ALL_ICONS = [...BASE_ICONS, ...ALPHABET];

  useEffect(() => {
    if (isOpen) {
      const p1 = localStorage.getItem('player1_config');
      const p2 = localStorage.getItem('player2_config');
      const savedColors = localStorage.getItem('unlocked_colors');
      const savedIcons = localStorage.getItem('unlocked_icons');
      const savedBg = localStorage.getItem('selected_background');
      const savedTimer = localStorage.getItem('vs_turn_timer');
      const maxLevel = parseInt(localStorage.getItem('arcade_level_max') || '0', 10);
      const matches = parseInt(localStorage.getItem('matches_played') || '0', 10);
      
      setArcadeLevelMax(maxLevel);
      setMatchesPlayed(matches);
      if (savedColors) setUnlockedColors(JSON.parse(savedColors));
      if (savedIcons) setUnlockedIcons(JSON.parse(savedIcons));

      if (p1) {
        const parsed = JSON.parse(p1);
        setP1Name(parsed.name);
        setP1Color(parsed.color);
        if (parsed.icon) setP1Icon(parsed.icon);
      }
      if (p2) {
        const parsed = JSON.parse(p2);
        setP2Name(parsed.name);
        setP2Color(parsed.color);
        if (parsed.icon) setP2Icon(parsed.icon);
      }
      if (savedTimer) setVsTimer(parseInt(savedTimer, 10));
      if (savedBg) setSelectedBg(savedBg);
    }
  }, [isOpen]);

  const handleSave = () => {
    localStorage.setItem('player1_config', JSON.stringify({ name: p1Name, color: p1Color, icon: p1Icon }));
    localStorage.setItem('player2_config', JSON.stringify({ name: p2Name, color: p2Color, icon: p2Icon }));
    localStorage.setItem('vs_turn_timer', vsTimer.toString());
    localStorage.setItem('selected_background', selectedBg);
    window.location.reload(); // Force reload to apply background changes globally
    onClose();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onCustomAudio) {
      onCustomAudio(file);
    }
  };

  const isIconLocked = (icon: IconType) => {
      if (BASE_ICONS.includes(icon)) {
          // Base icons: X, O are free. 1, 0, S unlock with early levels.
          if (icon === 'X' || icon === 'O') return false;
          if (icon === '1' || icon === '0' || icon === 'S') return !(arcadeLevelMax >= 5 || matchesPlayed >= 20);
      }
      // Alphabet unlocked via Arcade logic (checked via localstorage usually, or level mapping)
      // We'll trust `unlockedIcons` array which will be populated in ArcadeMode
      return !unlockedIcons.includes(icon) && !BASE_ICONS.includes(icon);
  };

  // Check if icon/color is taken by the OTHER player
  const isColorTaken = (hex: string, player: 'P1' | 'P2') => {
      return player === 'P1' ? hex === p2Color : hex === p1Color;
  };

  const isIconTaken = (icon: IconType, player: 'P1' | 'P2') => {
      return player === 'P1' ? icon === p2Icon : icon === p1Icon;
  };

  const renderColorGrid = (selectedColor: string, onSelect: (c: string) => void, player: 'P1' | 'P2') => (
    <div className="grid grid-cols-5 gap-3 max-h-[150px] overflow-y-auto pr-2 custom-scrollbar">
      {NEON_COLORS.map((c) => {
        const isLocked = c.locked && !unlockedColors.includes(c.hex);
        const isTaken = isColorTaken(c.hex, player);
        const isDisabled = isLocked || isTaken;

        return (
          <button
            key={c.hex}
            disabled={isDisabled}
            onClick={() => onSelect(c.hex)}
            className={`
              relative aspect-square rounded-xl border-2 transition-all group
              ${selectedColor === c.hex ? 'border-white scale-110' : 'border-transparent'}
              ${isDisabled ? 'bg-slate-800 opacity-50 cursor-not-allowed' : ''}
            `}
            style={{ backgroundColor: isDisabled ? undefined : c.hex }}
          >
            {isLocked && !isTaken && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Lock size={12} className="text-slate-500" />
              </div>
            )}
            {isTaken && (
               <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80 rounded-lg">
                 <Ban size={16} className="text-red-500" />
               </div>
            )}
            {selectedColor === c.hex && !isDisabled && (
               <div className="absolute inset-0 flex items-center justify-center">
                 <CheckCircle2 size={16} className="text-white drop-shadow-md" />
               </div>
            )}
          </button>
        );
      })}
    </div>
  );

  const renderIconSelector = (selectedIcon: IconType, onSelect: (i: IconType) => void, player: 'P1' | 'P2') => (
      <div className="grid grid-cols-6 gap-2 p-2 bg-slate-800/50 rounded-xl overflow-y-auto max-h-[150px] custom-scrollbar">
          {ALL_ICONS.map(icon => {
              const locked = isIconLocked(icon);
              const taken = isIconTaken(icon, player);
              const disabled = locked || taken;

              return (
                <button
                    key={icon}
                    disabled={disabled}
                    onClick={() => onSelect(icon)}
                    className={`aspect-square flex items-center justify-center rounded-lg border-2 transition-all font-black text-xl relative 
                    ${selectedIcon === icon ? 'bg-cyan-500 text-white border-cyan-400' : 'bg-slate-900 text-slate-500 border-slate-700'}
                    ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-cyan-500/50'}
                    `}
                >
                    {locked && !taken ? <Lock size={12} /> : icon}
                    {taken && (
                        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 rounded-lg">
                            <Ban size={12} className="text-red-500" />
                        </div>
                    )}
                </button>
              )
          })}
      </div>
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="bg-slate-900 border-2 border-slate-700 rounded-3xl max-w-lg w-full relative overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-20" />
            
            {/* Header */}
            <div className="p-8 pb-4 flex justify-between items-center bg-slate-900 z-10">
              <h2 className="text-2xl font-black text-slate-100 flex items-center gap-3">
                <Terminal className="text-cyan-400" />
                CONFIG_MENU
              </h2>
              <button onClick={onClose} className="text-slate-400 hover:text-white">
                <X />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex px-8 border-b border-slate-800 gap-4">
              <button 
                onClick={() => setActiveTab('SYSTEM')} 
                className={`pb-3 text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'SYSTEM' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-slate-500 hover:text-white'}`}
              >
                System
              </button>
              <button 
                onClick={() => setActiveTab('P1')} 
                className={`pb-3 text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'P1' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-slate-500 hover:text-white'}`}
              >
                Player 1
              </button>
              <button 
                onClick={() => setActiveTab('P2')} 
                className={`pb-3 text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'P2' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-slate-500 hover:text-white'}`}
              >
                Player 2
              </button>
            </div>

            {/* Content Area */}
            <div className="p-8 space-y-6 overflow-y-auto">
              
              {/* SYSTEM TAB */}
              {activeTab === 'SYSTEM' && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                  
                  {/* Background Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                        <ImageIcon size={12} /> Neural Environment
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                        {BACKGROUNDS.map(bg => {
                            const locked = arcadeLevelMax < bg.unlockLevel;
                            return (
                                <button
                                    key={bg.id}
                                    disabled={locked}
                                    onClick={() => setSelectedBg(bg.id)}
                                    className={`p-3 rounded-xl border text-left transition-all ${selectedBg === bg.id ? 'bg-cyan-900/30 border-cyan-500 text-cyan-400' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
                                >
                                    <div className="text-xs font-bold flex justify-between">
                                        {bg.name}
                                        {locked && <Lock size={12} />}
                                    </div>
                                    {locked && <div className="text-[8px] opacity-60">Unlock at Lv {bg.unlockLevel}</div>}
                                </button>
                            );
                        })}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-2xl border border-slate-700">
                    <div className="flex items-center gap-3">
                      {musicEnabled ? <Volume2 className="text-cyan-400" /> : <VolumeX className="text-slate-500" />}
                      <span className="font-bold text-slate-200 text-sm">Neural Audio</span>
                    </div>
                    <button
                      onClick={() => onMusicToggle(!musicEnabled)}
                      className={`w-14 h-8 rounded-full transition-colors relative ${musicEnabled ? 'bg-cyan-500 shadow-[0_0_10px_#06b6d4]' : 'bg-slate-700'}`}
                    >
                      <motion.div
                        animate={{ x: musicEnabled ? 24 : 4 }}
                        className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-md"
                      />
                    </button>
                  </div>

                  {/* VS Turn Timer Config */}
                  <div className="space-y-2">
                    <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">VS_MODE_Turn_Timer</div>
                    <div className="grid grid-cols-4 gap-2">
                        {[3, 6, 12, 30].map(time => (
                            <button
                                key={time}
                                onClick={() => setVsTimer(time)}
                                className={`py-3 rounded-xl border-2 font-black transition-all ${
                                    vsTimer === time 
                                    ? 'border-cyan-500 bg-cyan-500/20 text-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.3)]' 
                                    : 'border-slate-800 bg-slate-800/50 text-slate-500 hover:border-slate-600'
                                }`}
                            >
                                {time}s
                            </button>
                        ))}
                    </div>
                  </div>

                  {/* Custom Audio Upload */}
                  <div className="space-y-2 pt-2">
                    <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Neural_Audio_Uplink</div>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className={`w-full group relative flex items-center justify-between p-4 bg-slate-800/30 border rounded-2xl transition-all shimmer-effect ${customAudioActive ? 'border-cyan-500 bg-cyan-500/5' : 'border-slate-700 hover:border-slate-500'}`}
                    >
                      <div className="flex items-center gap-3">
                        {customAudioActive ? (
                          <CheckCircle2 className="text-cyan-400" size={20} />
                        ) : (
                          <Music className="text-slate-500 group-hover:text-cyan-400 transition-colors" size={20} />
                        )}
                        <div className="text-left">
                          <div className="text-sm font-bold text-slate-200">
                            {customAudioActive ? 'CUSTOM_STREAM_ACTIVE' : 'LOAD_NEURAL_AUDIO'}
                          </div>
                          <div className="text-[9px] text-slate-500 font-mono">MP3 / WAV / OGG PROTOCOL</div>
                        </div>
                      </div>
                      <Upload size={18} className="text-slate-600 group-hover:text-white transition-colors" />
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        accept="audio/*"
                        className="hidden"
                      />
                    </button>
                  </div>
                </motion.div>
              )}

              {/* PLAYER 1 TAB */}
              {activeTab === 'P1' && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                        <User size={12} /> Designator
                    </label>
                    <div className="relative">
                        <input 
                           type="text" 
                           value={p1Name} 
                           onChange={(e) => setP1Name(e.target.value.toUpperCase().slice(0, 12))}
                           className="w-full bg-slate-800 border-2 border-slate-700 rounded-xl px-4 py-3 text-white font-black tracking-wider focus:border-cyan-400 focus:outline-none transition-colors"
                        />
                        <Edit2 size={14} className="absolute right-4 top-4 text-slate-500" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                        <Terminal size={12} /> Glyph Protocol
                    </label>
                    {renderIconSelector(p1Icon, setP1Icon, 'P1')}
                    <div className="text-[8px] text-slate-500 italic mt-1">Unlock more by clearing Arcade Levels.</div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                        <Palette size={12} /> Signature Hue
                    </label>
                    {renderColorGrid(p1Color, setP1Color, 'P1')}
                    <div className="text-[8px] text-slate-500 italic mt-1">Colors unlock randomly in Arcade Mode.</div>
                  </div>
                </motion.div>
              )}

              {/* PLAYER 2 TAB */}
              {activeTab === 'P2' && (
                 <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                       <User size={12} /> Designator
                   </label>
                   <div className="relative">
                       <input 
                          type="text" 
                          value={p2Name} 
                          onChange={(e) => setP2Name(e.target.value.toUpperCase().slice(0, 12))}
                          className="w-full bg-slate-800 border-2 border-slate-700 rounded-xl px-4 py-3 text-white font-black tracking-wider focus:border-cyan-400 focus:outline-none transition-colors"
                       />
                       <Edit2 size={14} className="absolute right-4 top-4 text-slate-500" />
                   </div>
                 </div>

                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                        <Terminal size={12} /> Glyph Protocol
                    </label>
                    {renderIconSelector(p2Icon, setP2Icon, 'P2')}
                  </div>

                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1 flex items-center gap-2">
                       <Palette size={12} /> Signature Hue
                   </label>
                   {renderColorGrid(p2Color, setP2Color, 'P2')}
                 </div>
               </motion.div>
              )}
            </div>

            <div className="p-8 pt-0 mt-auto">
              <button
                onClick={handleSave}
                className="w-full py-4 rounded-2xl bg-white text-slate-900 font-black hover:bg-cyan-400 transition-colors shadow-lg"
              >
                SAVE CONFIGURATION
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default SettingsMenu;
