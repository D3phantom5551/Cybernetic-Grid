
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChevronLeft, RotateCcw, Swords, Home, Play, Info, Menu } from 'lucide-react';
import GameGrid from '../components/GameGrid';
import PauseMenu from '../components/PauseMenu';
import { GridCell, Player, NEON_COLORS, IconType, BACKGROUNDS } from '../types';

const GRID_SIZE = 3;
const WIN_COUNT = 3;

const ClassicMode: React.FC = () => {
  const navigate = useNavigate();
  const [isPaused, setIsPaused] = useState(false);
  const [board, setBoard] = useState<GridCell[][]>(() => createInitialBoard());
  const [currentPlayer, setCurrentPlayer] = useState<Player>('BLUE');
  const [winner, setWinner] = useState<Player | 'DRAW' | null>(null);

  // Player Config State
  const [p1Config, setP1Config] = useState({ name: 'OP_ALPHA', color: NEON_COLORS[0].hex, icon: 'X' as IconType });
  const [p2Config, setP2Config] = useState({ name: 'OP_BETA', color: NEON_COLORS[1].hex, icon: 'O' as IconType });
  const [currentBgCss, setCurrentBgCss] = useState('bg-[#020617]');

  useEffect(() => {
    // Load config from local storage
    const savedP1 = localStorage.getItem('player1_config');
    const savedP2 = localStorage.getItem('player2_config');
    const savedBgId = localStorage.getItem('selected_background') || 'DEFAULT';

    const bg = BACKGROUNDS.find(b => b.id === savedBgId);
    if (bg) setCurrentBgCss(bg.css);

    let loadedP1 = savedP1 ? JSON.parse(savedP1) : { name: 'OP_ALPHA', color: NEON_COLORS[0].hex, icon: 'X' };
    let loadedP2 = savedP2 ? JSON.parse(savedP2) : { name: 'OP_BETA', color: NEON_COLORS[1].hex, icon: 'O' };

    // Conflict Resolution Logic (Backup in case Settings didn't catch it)
    if (loadedP1.color === loadedP2.color) {
        const availableColors = NEON_COLORS.filter(c => c.hex !== loadedP1.color);
        loadedP2.color = availableColors[0]?.hex || NEON_COLORS[1].hex;
    }
    if (loadedP1.icon === loadedP2.icon) {
        const icons: IconType[] = ['X', 'O', '1', '0', 'S'];
        loadedP2.icon = icons.find(i => i !== loadedP1.icon) || 'O';
    }

    setP1Config(loadedP1);
    setP2Config(loadedP2);
  }, []);

  // Update matches played on win
  useEffect(() => {
      if (winner) {
          const matches = parseInt(localStorage.getItem('matches_played') || '0', 10);
          localStorage.setItem('matches_played', (matches + 1).toString());
      }
  }, [winner]);

  function createInitialBoard(): GridCell[][] {
    return Array(GRID_SIZE).fill(null).map((_, y) => 
      Array(GRID_SIZE).fill(null).map((_, x) => ({ 
        id: `${x}-${y}-${Math.random()}`, 
        x, y, 
        owner: null, 
        powerUp: 'NONE' 
      }))
    );
  }

  const handleRestart = () => {
    setBoard(createInitialBoard());
    setCurrentPlayer('BLUE');
    setWinner(null);
    setIsPaused(false);
  };

  const checkWinner = (newBoard: GridCell[][]): Player | 'DRAW' | null => {
    // Horizontal & Vertical
    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j <= GRID_SIZE - WIN_COUNT; j++) {
        // Rows
        const rowSlice = newBoard[i].slice(j, j + WIN_COUNT);
        if (rowSlice.every(c => c.owner === 'BLUE')) return 'BLUE';
        if (rowSlice.every(c => c.owner === 'RED')) return 'RED';

        // Cols
        const colSlice = Array.from({ length: WIN_COUNT }).map((_, k) => newBoard[j + k][i]);
        if (colSlice.every(c => c.owner === 'BLUE')) return 'BLUE';
        if (colSlice.every(c => c.owner === 'RED')) return 'RED';
      }
    }

    // Diagonals
    for (let y = 0; y <= GRID_SIZE - WIN_COUNT; y++) {
      for (let x = 0; x <= GRID_SIZE - WIN_COUNT; x++) {
        const diag1 = Array.from({ length: WIN_COUNT }).map((_, k) => newBoard[y + k][x + k]);
        if (diag1.every(c => c.owner === 'BLUE')) return 'BLUE';
        if (diag1.every(c => c.owner === 'RED')) return 'RED';

        const diag2 = Array.from({ length: WIN_COUNT }).map((_, k) => newBoard[y + k][x + WIN_COUNT - 1 - k]);
        if (diag2.every(c => c.owner === 'BLUE')) return 'BLUE';
        if (diag2.every(c => c.owner === 'RED')) return 'RED';
      }
    }

    if (newBoard.every(row => row.every(c => c.owner !== null))) return 'DRAW';
    return null;
  };

  const handleCellClick = (x: number, y: number) => {
    if (winner || board[y][x].owner || isPaused) return;

    const newBoard = JSON.parse(JSON.stringify(board));
    newBoard[y][x].owner = currentPlayer;
    
    const result = checkWinner(newBoard);
    if (result) {
      setWinner(result);
    } else {
      setCurrentPlayer(prev => prev === 'BLUE' ? 'RED' : 'BLUE');
    }
    setBoard(newBoard);
  };

  // Keyboard shortcut for Pause
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !winner) setIsPaused(p => !p);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [winner]);

  return (
    <div className={`min-h-screen ${currentBgCss} p-4 md:p-8 font-mono relative overflow-hidden flex flex-col items-center justify-center`}>
      <div className="absolute inset-0 opacity-10 pointer-events-none grid-bg" />
      
      {/* HUD Bar */}
      <div className="fixed top-[max(1rem,env(safe-area-inset-top))] inset-x-0 px-4 md:px-8 flex flex-nowrap justify-between items-center z-50 w-full gap-2">
        <button onClick={() => setIsPaused(true)} className="flex-shrink-0 p-2 md:p-3 bg-slate-900/50 border border-white/5 rounded-xl text-slate-500 hover:text-white transition-all flex items-center gap-2">
          <Menu size={18} /> <span className="hidden md:inline font-black text-[10px] uppercase tracking-widest">PAUSE</span>
        </button>

        <div className="flex-shrink flex flex-col items-center mx-1 md:mx-4 overflow-hidden">
           <div className="px-2 md:px-8 py-2 md:py-3 bg-slate-900/80 border border-white/5 rounded-full backdrop-blur-md flex items-center gap-2 md:gap-6">
              <div className={`flex items-center gap-2 md:gap-3 transition-opacity ${currentPlayer === 'BLUE' ? 'opacity-100' : 'opacity-20'}`}>
                <div className="w-2 h-2 md:w-3 md:h-3 rounded-full shadow-[0_0_10px]" style={{ backgroundColor: p1Config.color, boxShadow: `0 0 10px ${p1Config.color}` }} />
                <span className="text-[10px] md:text-xs font-black text-white italic truncate max-w-[60px] md:max-w-none">{p1Config.name}</span>
              </div>
              <div className="w-px h-4 bg-white/10" />
              <div className={`flex items-center gap-2 md:gap-3 transition-opacity ${currentPlayer === 'RED' ? 'opacity-100' : 'opacity-20'}`}>
                <span className="text-[10px] md:text-xs font-black text-white italic truncate max-w-[60px] md:max-w-none">{p2Config.name}</span>
                <div className="w-2 h-2 md:w-3 md:h-3 rounded-full shadow-[0_0_10px]" style={{ backgroundColor: p2Config.color, boxShadow: `0 0 10px ${p2Config.color}` }} />
              </div>
           </div>
        </div>

        <button onClick={handleRestart} className="flex-shrink-0 p-2 md:p-3 bg-slate-900/50 border border-white/5 rounded-xl text-slate-500 hover:text-white transition-all">
          <RotateCcw size={16} />
        </button>
      </div>

      <div className="w-full max-w-[480px] space-y-8 relative z-10 pt-32 md:pt-0">
        <div className="text-center">
           <h2 className="text-xl md:text-2xl font-black italic text-white tracking-tighter uppercase mb-2">Classic_Link Protocol</h2>
           <p className="text-[10px] text-lime-400 font-bold uppercase tracking-[0.4em]">Grid_3x3 // Connect_3_To_Win</p>
        </div>

        <GameGrid 
          board={board} 
          onCellClick={handleCellClick} 
          currentPlayer={currentPlayer} 
          playerColors={{ BLUE: p1Config.color, RED: p2Config.color }}
          playerIcons={{ BLUE: p1Config.icon, RED: p2Config.icon }}
          stageColor="#a3e635"
        />

        <div className="text-center">
           <span className="text-[8px] md:text-[10px] text-slate-700 font-black tracking-[0.8em] uppercase opacity-40">Neural_Bridge_Active // Classic_Sequence_Locked</span>
        </div>
      </div>

      <PauseMenu 
        isOpen={isPaused} 
        onClose={() => setIsPaused(false)} 
        onRestart={handleRestart} 
      />

      <AnimatePresence>
        {winner && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/95 backdrop-blur-2xl p-6 shimmer-effect">
            <motion.div initial={{ scale: 0.8, opacity: 0, y: 30 }} animate={{ scale: 1, opacity: 1, y: 0 }} className="text-center space-y-8 md:space-y-12 max-w-lg relative z-10">
              <div className="space-y-4">
                <Swords size={60} className="mx-auto text-white md:w-20 md:h-20 drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]" />
                <h2 className="text-4xl md:text-7xl font-black italic text-white tracking-tighter uppercase" style={{ textShadow: '0 0 30px rgba(255,255,255,0.3)' }}>
                  {winner === 'DRAW' ? 'Grid_Stalemate' : 'Link_Dominance'}
                </h2>
                {winner !== 'DRAW' && (
                  <p className="text-2xl md:text-4xl font-black uppercase tracking-[0.3em] italic" style={{ 
                    color: winner === 'BLUE' ? p1Config.color : p2Config.color,
                    textShadow: `0 0 20px ${winner === 'BLUE' ? p1Config.color : p2Config.color}`
                  }}>
                    {winner === 'BLUE' ? p1Config.name : p2Config.name} Victors
                  </p>
                )}
              </div>

              <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
                <button 
                  onClick={handleRestart} 
                  className="w-full md:flex-1 px-12 py-6 bg-white text-slate-950 font-black italic text-xl rounded-2xl hover:bg-lime-400 transition-all uppercase flex items-center justify-center gap-3 shadow-[0_0_30px_rgba(255,255,255,0.1)] group"
                >
                  <Play className="group-hover:translate-x-1 transition-transform" /> RE-LINK
                </button>
                <button 
                  onClick={() => navigate('/')} 
                  className="w-full md:flex-1 px-12 py-6 bg-slate-900 border-2 border-white/10 text-white font-black italic text-xl rounded-2xl hover:border-white transition-all uppercase flex items-center justify-center gap-3"
                >
                  <Home /> EXIT
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ClassicMode;
