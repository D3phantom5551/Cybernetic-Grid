
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Users, Trophy, User, BookOpen, Award, Settings, Shield, Cpu, AlertTriangle, Activity, Grid3X3 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import SettingsMenu from '../components/SettingsMenu';

interface HomeProps {
  musicEnabled: boolean;
  onMusicToggle: (val: boolean) => void;
  onCustomAudio?: (file: File) => void;
  customAudioActive?: boolean;
}

const Home: React.FC<HomeProps> = ({ musicEnabled, onMusicToggle, onCustomAudio, customAudioActive }) => {
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const [suddenDeathEnabled, setSuddenDeathEnabled] = useState(false);

  const startMode = (path: string) => {
    navigate(path, { state: { suddenDeath: suddenDeathEnabled } });
  };

  return (
    <div className={`min-h-screen transition-colors duration-1000 ${suddenDeathEnabled ? 'bg-[#0a0202]' : 'bg-[#020617]'} flex items-center justify-center p-4 relative overflow-hidden font-mono`}>
      <div className={`absolute inset-0 opacity-10 pointer-events-none grid-bg transition-opacity duration-1000 ${suddenDeathEnabled ? 'opacity-20' : 'opacity-10'}`} />
      
      {/* Dynamic Background Glows */}
      <motion.div 
        animate={{ scale: [1, 1.2, 1], opacity: suddenDeathEnabled ? [0.2, 0.4, 0.2] : [0.1, 0.2, 0.1] }}
        transition={{ duration: 10, repeat: Infinity }}
        className={`absolute top-[-10%] left-[-10%] w-[50%] h-[50%] ${suddenDeathEnabled ? 'bg-red-600' : 'bg-cyan-500'} rounded-full blur-[120px] pointer-events-none transition-colors duration-1000`} 
      />
      <motion.div 
        animate={{ scale: [1.2, 1, 1.2], opacity: suddenDeathEnabled ? [0.2, 0.4, 0.2] : [0.1, 0.2, 0.1] }}
        transition={{ duration: 12, repeat: Infinity }}
        className={`absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] ${suddenDeathEnabled ? 'bg-orange-600' : 'bg-fuchsia-500'} rounded-full blur-[120px] pointer-events-none transition-colors duration-1000`} 
      />

      <div className="relative z-10 max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: -40 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10 md:mb-14 space-y-2">
          <h1 className="text-6xl md:text-9xl font-black italic tracking-tighter text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.2)]">
            CYBERNETIC
          </h1>
          <h2 className={`text-3xl md:text-6xl font-black italic tracking-[0.2em] transition-colors duration-500 ${suddenDeathEnabled ? 'text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.6)]' : 'text-cyan-400 drop-shadow-[0_0_20px_rgba(34,211,238,0.4)]'}`}>
            GRID
          </h2>
          <div className="flex items-center justify-center gap-6 pt-4 md:pt-6">
             <div className="h-[2px] w-12 md:w-24 bg-gradient-to-r from-transparent to-slate-800" />
             <span className="text-[10px] md:text-[12px] text-slate-500 font-black uppercase tracking-[0.5em] px-4">Core_System_Online</span>
             <div className="h-[2px] w-12 md:w-24 bg-gradient-to-l from-transparent to-slate-800" />
          </div>
        </motion.div>

        {/* Neural Modifiers */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-xl mx-auto mb-10 px-6 py-4 bg-slate-900/40 border border-white/5 rounded-[30px] backdrop-blur-xl flex items-center justify-between shadow-2xl"
        >
          <div className="flex items-center gap-4">
            <div className={`p-2 rounded-xl transition-colors ${suddenDeathEnabled ? 'bg-red-500/20' : 'bg-slate-800'}`}>
              <AlertTriangle className={`w-5 h-5 transition-colors ${suddenDeathEnabled ? 'text-red-500' : 'text-slate-500'}`} />
            </div>
            <div>
              <div className="text-[10px] font-black uppercase tracking-widest text-white">Sudden Death Protocol</div>
              <div className="text-[8px] font-bold uppercase tracking-wider text-slate-500">Instant Neural Core Depletion</div>
            </div>
          </div>
          
          <button 
            onClick={() => setSuddenDeathEnabled(!suddenDeathEnabled)}
            className={`group relative flex items-center h-8 w-14 rounded-full transition-all duration-300 ${suddenDeathEnabled ? 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.5)]' : 'bg-slate-800'}`}
          >
            <motion.div 
              animate={{ x: suddenDeathEnabled ? 28 : 4 }}
              className="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-lg"
            >
              <Activity size={12} className={suddenDeathEnabled ? 'text-red-600' : 'text-slate-400'} />
            </motion.div>
          </button>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 md:gap-8 mb-12 md:mb-16">
          <motion.button
            whileHover={{ scale: 1.03, translateY: -8 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => startMode('/VSMode')}
            className="group relative h-64 md:h-72 bg-slate-900/40 border border-white/5 rounded-[40px] p-8 flex flex-col justify-end overflow-hidden text-left backdrop-blur-xl transition-all hover:border-fuchsia-500/40"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-30 group-hover:scale-110 transition-all duration-700 text-fuchsia-400">
              <Users size={120} />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-fuchsia-950/30 via-transparent to-transparent" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-fuchsia-500/20 rounded-lg text-fuchsia-400">
                  <Shield size={18} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-fuchsia-400">Tactical_Arena</span>
              </div>
              <h3 className="text-2xl md:text-3xl font-black text-white italic mb-2 tracking-tighter">VS_PROTOCOL</h3>
              <p className="text-slate-500 text-[10px] leading-relaxed font-bold uppercase tracking-widest opacity-60">Local combat with HP scaling.</p>
            </div>
            <div className="absolute bottom-0 left-0 w-full h-1 bg-fuchsia-500 shadow-[0_0_20px_#e879f9] group-hover:h-2 transition-all" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.03, translateY: -8 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => startMode('/ArcadeMode')}
            className="group relative h-64 md:h-72 bg-slate-900/40 border border-white/5 rounded-[40px] p-8 flex flex-col justify-end overflow-hidden text-left backdrop-blur-xl transition-all hover:border-cyan-500/40"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-30 group-hover:scale-110 transition-all duration-700 text-cyan-400">
              <Trophy size={120} />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-cyan-950/30 via-transparent to-transparent" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-cyan-500/20 rounded-lg text-cyan-400">
                  <Cpu size={18} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-cyan-400">Neural_Sequence</span>
              </div>
              <h3 className="text-2xl md:text-3xl font-black text-white italic mb-2 tracking-tighter">ARCADE_SEQUENCE</h3>
              <p className="text-slate-500 text-[10px] leading-relaxed font-bold uppercase tracking-widest opacity-60">AI combat & Sector progression.</p>
            </div>
            <div className="absolute bottom-0 left-0 w-full h-1 bg-cyan-500 shadow-[0_0_20px_#22d3ee] group-hover:h-2 transition-all" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.03, translateY: -8 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => startMode('/ClassicMode')}
            className="group relative h-64 md:h-72 bg-slate-900/40 border border-white/5 rounded-[40px] p-8 flex flex-col justify-end overflow-hidden text-left backdrop-blur-xl transition-all hover:border-lime-500/40"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-30 group-hover:scale-110 transition-all duration-700 text-lime-400">
              <Grid3X3 size={120} />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-lime-950/30 via-transparent to-transparent" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-lime-500/20 rounded-lg text-lime-400">
                  <Activity size={18} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-lime-400">Standard_Link</span>
              </div>
              <h3 className="text-2xl md:text-3xl font-black text-white italic mb-2 tracking-tighter">CLASSIC_MODE</h3>
              <p className="text-slate-500 text-[10px] leading-relaxed font-bold uppercase tracking-widest opacity-60">Traditional 3x3 Link-3. Pure tactical.</p>
            </div>
            <div className="absolute bottom-0 left-0 w-full h-1 bg-lime-500 shadow-[0_0_20px_#a3e635] group-hover:h-2 transition-all" />
          </motion.button>
        </div>

        <div className="flex flex-wrap justify-center gap-6 md:gap-10">
          <motion.button whileHover={{ scale: 1.1 }} onClick={() => navigate('/PlayerProfile')} className="flex items-center gap-3 text-slate-500 hover:text-white transition-all group">
            <User size={20} className="group-hover:text-cyan-400 transition-colors" /> 
            <span className="text-[12px] font-black tracking-[0.2em] uppercase">Operator_Stats</span>
          </motion.button>
          <motion.button whileHover={{ scale: 1.1 }} onClick={() => navigate('/TrainingMode')} className="flex items-center gap-3 text-slate-500 hover:text-white transition-all group">
            <BookOpen size={20} className="group-hover:text-fuchsia-400 transition-colors" /> 
            <span className="text-[12px] font-black tracking-[0.2em] uppercase">Combat_Manual</span>
          </motion.button>
          <motion.button whileHover={{ scale: 1.1 }} onClick={() => setShowSettings(true)} className="flex items-center gap-3 text-slate-500 hover:text-white transition-all group">
            <Settings size={20} className="group-hover:text-amber-400 transition-colors" /> 
            <span className="text-[12px] font-black tracking-[0.2em] uppercase">Config_Menu</span>
          </motion.button>
        </div>
      </div>
      
      <SettingsMenu 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
        musicEnabled={musicEnabled} 
        onMusicToggle={onMusicToggle} 
        onCustomAudio={onCustomAudio}
        customAudioActive={customAudioActive}
      />
    </div>
  );
};

export default Home;
