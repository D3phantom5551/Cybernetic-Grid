
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, BookOpen, Zap, Shield, Target, Flame, Heart, Activity, Skull, Home } from 'lucide-react';
import { PowerUpType } from '../types';

const TrainingMode: React.FC = () => {
  const navigate = useNavigate();
  const [section, setSection] = useState(0);

  const SECTIONS = [
    {
      id: 'BASICS',
      title: 'Combat Fundamentals',
      icon: <BookOpen className="text-cyan-400" size={32} />,
      content: (
        <div className="space-y-6">
          <p className="text-sm text-slate-300 leading-relaxed">
            Your objective is to deplete the opponent's <span className="text-cyan-400 font-bold">Life Points (LP)</span> to zero. 
            The grid is your battlefield.
          </p>
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-700 space-y-4">
            <h3 className="text-white font-bold text-lg flex items-center gap-2">
              <Zap size={18} className="text-yellow-400" /> Taking Action
            </h3>
            <ul className="text-xs text-slate-400 space-y-2 list-disc pl-4">
              <li>Click an empty cell to place your node.</li>
              <li>Connecting <span className="text-white font-bold">3 nodes</span> in a line (horizontal, vertical, diagonal) triggers an attack.</li>
              <li>Attacks deal <span className="text-red-400 font-bold">damage</span> to the opponent.</li>
              <li>The matched nodes are consumed (removed) from the grid after the attack.</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      id: 'POWERUPS',
      title: 'Power-Up Protocols',
      icon: <Target className="text-fuchsia-400" size={32} />,
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            Special nodes appear on the grid. Include them in a match-3 line to activate their effect.
          </p>
          <div className="grid grid-cols-1 gap-3">
            {[
              { type: 'FIRE', icon: Flame, color: '#fb923c', desc: 'Incineration: Deals +25 bonus damage immediately.' },
              { type: 'SHIELD', icon: Shield, color: '#60a5fa', desc: 'Barrier: Blocks the next instance of incoming damage completely.' },
              { type: 'LIGHTNING', icon: Zap, color: '#facc15', desc: 'Overload: Deals +15 bonus damage.' },
              { type: 'HEAL', icon: Heart, color: '#4ade80', desc: 'Repair: Restores +20 LP to your core.' },
              { type: 'CRIT', icon: Target, color: '#c026d3', desc: 'Amplify: Your NEXT attack deals double damage (2x).' },
            ].map(p => (
              <div key={p.type} className="flex items-center gap-4 p-3 bg-slate-900/50 rounded-xl border border-slate-800">
                <div className="p-2 rounded-lg bg-slate-950 shadow-inner">
                  <p.icon size={20} style={{ color: p.color }} />
                </div>
                <div>
                  <div className="text-xs font-black text-white">{p.type}</div>
                  <div className="text-[10px] text-slate-400">{p.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      id: 'STRATEGY',
      title: 'Tactical Analysis',
      icon: <Activity className="text-lime-400" size={32} />,
      content: (
        <div className="space-y-6">
          <div className="bg-slate-900/80 p-5 rounded-2xl border-l-4 border-lime-500">
            <h4 className="text-lime-400 font-bold text-sm mb-2">Denial of Service</h4>
            <p className="text-xs text-slate-300">
              Watch your opponent's lines. If they have 2 nodes in a row, place your node to block them. 
              Blocking prevents them from dealing damage and gaining momentum.
            </p>
          </div>
          <div className="bg-slate-900/80 p-5 rounded-2xl border-l-4 border-purple-500">
            <h4 className="text-purple-400 font-bold text-sm mb-2">Resource Management</h4>
            <p className="text-xs text-slate-300">
              Don't just attack blindly. If you are low on health, prioritize <span className="text-green-400">HEAL</span> or <span className="text-blue-400">SHIELD</span> power-ups over damage.
              A shield can block a massive critical hit from an opponent.
            </p>
          </div>
        </div>
      )
    },
    {
      id: 'SUDDEN_DEATH',
      title: 'Sudden Death',
      icon: <Skull className="text-red-500" size={32} />,
      content: (
        <div className="space-y-6 text-center">
          <div className="w-20 h-20 mx-auto bg-red-500/10 rounded-full flex items-center justify-center border-2 border-red-500 animate-pulse">
            <Skull size={40} className="text-red-500" />
          </div>
          <h3 className="text-2xl font-black text-white italic">TOTAL SYSTEM FAILURE</h3>
          <p className="text-sm text-slate-300">
            If the match timer expires (0:00) or the grid becomes completely full with no winner:
          </p>
          <div className="bg-red-950/30 p-6 rounded-2xl border border-red-500/30">
            <ul className="text-sm text-red-200 space-y-4 font-mono">
              <li className="flex items-center gap-3">
                <span className="text-xl font-bold">1.</span> All HP regeneration is disabled.
              </li>
              <li className="flex items-center gap-3">
                <span className="text-xl font-bold">2.</span> Both players lose <span className="font-bold bg-red-600 text-white px-2 py-0.5 rounded">1 LP every 2 seconds</span>.
              </li>
              <li className="flex items-center gap-3">
                <span className="text-xl font-bold">3.</span> The last operator standing wins.
              </li>
            </ul>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 p-6 md:p-12 font-mono flex flex-col items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 opacity-10 pointer-events-none grid-bg" />
      
      <div className="w-full max-w-4xl relative z-10">
        <button onClick={() => navigate('/')} className="mb-8 flex items-center gap-2 text-slate-500 hover:text-white transition-colors">
          <ChevronLeft /> RETURN TO BASE
        </button>

        <div className="flex flex-col md:flex-row gap-8 h-[600px]">
          {/* Navigation Sidebar */}
          <div className="md:w-1/3 flex flex-col gap-3">
            <h1 className="text-4xl font-black italic text-white mb-6 tracking-tighter">TRAINING<br/>MODULE</h1>
            {SECTIONS.map((sec, idx) => (
              <button
                key={sec.id}
                onClick={() => setSection(idx)}
                className={`text-left p-4 rounded-2xl border-2 transition-all flex items-center gap-4 group ${section === idx ? 'bg-slate-800 border-cyan-500 shadow-[0_0_15px_rgba(34,211,238,0.2)]' : 'bg-slate-900/50 border-slate-800 hover:border-slate-600'}`}
              >
                <div className={`transition-transform ${section === idx ? 'scale-110' : 'group-hover:scale-110'}`}>
                  {sec.icon}
                </div>
                <div>
                  <div className={`text-xs font-black uppercase tracking-wider ${section === idx ? 'text-white' : 'text-slate-500'}`}>
                    Module 0{idx + 1}
                  </div>
                  <div className={`font-bold ${section === idx ? 'text-cyan-400' : 'text-slate-300'}`}>
                    {sec.title}
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Content Area */}
          <div className="flex-1 bg-slate-900/80 border border-slate-700 rounded-[40px] p-8 md:p-12 relative overflow-hidden backdrop-blur-xl shadow-2xl">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-20" />
            
            <AnimatePresence mode="wait">
              <motion.div
                key={section}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="h-full flex flex-col"
              >
                <div className="flex items-center gap-4 mb-8 border-b border-slate-800 pb-6">
                  {SECTIONS[section].icon}
                  <h2 className="text-3xl font-black text-white italic">{SECTIONS[section].title}</h2>
                </div>
                
                <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar">
                  {SECTIONS[section].content}
                </div>

                <div className="pt-8 flex justify-between mt-auto">
                  <button 
                    onClick={() => setSection(s => Math.max(0, s - 1))}
                    disabled={section === 0}
                    className={`flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors ${section === 0 ? 'opacity-0 pointer-events-none' : 'text-slate-500 hover:text-white'}`}
                  >
                    <ChevronLeft /> Previous
                  </button>
                  {section < SECTIONS.length - 1 ? (
                    <button 
                        onClick={() => setSection(s => Math.min(SECTIONS.length - 1, s + 1))}
                        className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-cyan-400 hover:text-white transition-colors"
                    >
                        Next Module <ChevronRight />
                    </button>
                  ) : (
                    <button 
                        onClick={() => navigate('/')}
                        className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-green-400 hover:text-white transition-colors"
                    >
                        Finish Training <Home size={16} />
                    </button>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrainingMode;
