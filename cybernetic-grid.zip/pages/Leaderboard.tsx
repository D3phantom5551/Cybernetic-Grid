
import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Trophy, Crown, Flame, Zap } from 'lucide-react';

const TOP_PLAYERS = [
  { rank: 1, name: "N30N_GH0ST", score: 45020, winRate: "89%", status: "Legend" },
  { rank: 2, name: "ZERO_COOL", score: 42100, winRate: "84%", status: "Pro" },
  { rank: 3, name: "V0ID_WALK3R", score: 38900, winRate: "81%", status: "Pro" },
  { rank: 4, name: "CYB3R_PUNK", score: 35600, winRate: "78%", status: "Elite" },
  { rank: 5, name: "OPERATOR_42", score: 31200, winRate: "64%", status: "Architect" },
  { rank: 6, name: "D1G1TAL_D4NE", score: 29800, winRate: "72%", status: "Elite" },
  { rank: 7, name: "BIT_K1LLER", score: 27400, winRate: "68%", status: "Specialist" },
];

const Leaderboard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-950 p-6 md:p-12 font-mono">
      <div className="max-w-4xl mx-auto">
        <button onClick={() => navigate('/')} className="mb-12 flex items-center gap-2 text-slate-500 hover:text-white transition-colors">
          <ChevronLeft /> RETURN
        </button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <Trophy size={64} className="mx-auto text-amber-400 mb-6 drop-shadow-[0_0_15px_rgba(251,191,36,0.4)]" />
          <h1 className="text-5xl font-black text-white italic tracking-tighter mb-4">GLOBAL_RANKS</h1>
          <p className="text-slate-500 text-sm">TOP DOMINANCE RATINGS ACROSS THE NEURAL NETWORK</p>
        </motion.div>

        <div className="bg-slate-900 border-2 border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="grid grid-cols-12 gap-4 p-6 bg-slate-800/50 text-slate-500 text-[10px] font-bold uppercase tracking-widest border-b border-slate-800">
            <div className="col-span-2">Rank</div>
            <div className="col-span-5">Operator</div>
            <div className="col-span-3 text-right">Dominance</div>
            <div className="col-span-2 text-right">Rating</div>
          </div>

          <div className="divide-y divide-slate-800">
            {TOP_PLAYERS.map((player, idx) => (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                key={player.name}
                className={`grid grid-cols-12 gap-4 p-6 items-center hover:bg-slate-800/30 transition-colors group ${player.name === 'OPERATOR_42' ? 'bg-cyan-500/5 border-l-4 border-cyan-500' : ''}`}
              >
                <div className="col-span-2 flex items-center gap-2">
                  {player.rank === 1 ? <Crown className="text-amber-400" size={18} /> : 
                   player.rank === 2 ? <Flame className="text-slate-400" size={18} /> : 
                   player.rank === 3 ? <Zap className="text-amber-700" size={18} /> : 
                   <span className="text-slate-600 font-bold ml-1">{player.rank}</span>}
                </div>
                <div className="col-span-5">
                  <div className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">{player.name}</div>
                  <div className="text-[10px] text-slate-600">{player.status}</div>
                </div>
                <div className="col-span-3 text-right font-black text-slate-400 text-sm">
                  {player.score.toLocaleString()}
                </div>
                <div className="col-span-2 text-right">
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${player.rank < 4 ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-800 text-slate-500'}`}>
                    {player.winRate}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="mt-8 text-center text-[10px] text-slate-700 animate-pulse">
          FETCHING LIVE UPDATES FROM NEURAL_CORE...
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;
