
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChevronLeft, RotateCcw, Cpu, Target, Zap, Clock, Flame, Menu, Home, Play, ArrowRight, BrainCircuit, Lock, Shield, Skull, Palette } from 'lucide-react';
import GameGrid from '../components/GameGrid';
import GameHUD from '../components/GameHUD';
import PauseMenu from '../components/PauseMenu';
import { GridCell, Player, GameState, NEON_COLORS, PowerUpType, DamageIndicator, IconType, BACKGROUNDS } from '../types';

const GRID_SIZE = 6;
const INITIAL_HP = 200;
const TURN_TIME = 6;
const MATCH_TIME = 360; // 6 minutes
const MAX_POWER_UPS = 8;
const POWER_UP_POOL: PowerUpType[] = ['FIRE', 'SHIELD', 'LIGHTNING', 'HEAL', 'CRIT'];
const POWER_UP_LIFETIME = 5;

type Difficulty = 'EASY' | 'MEDIUM' | 'HARD' | 'EXTREME' | 'NIGHTMARE';

const ArcadeMode: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const initialSuddenDeath = location.state?.suddenDeath || false;

  const [gameStarted, setGameStarted] = useState(false);

  const [stageLevel, setStageLevel] = useState(1);
  const [isPaused, setIsPaused] = useState(false);
  const [damageIndicators, setDamageIndicators] = useState<DamageIndicator[]>([]);
  const [unlockMessage, setUnlockMessage] = useState<string | null>(null);
  
  // Player Config State
  const [p1Config, setP1Config] = useState({ name: 'OP_ALPHA', color: NEON_COLORS[0].hex, icon: 'X' as IconType });
  // AI Config State
  const [aiConfig, setAiConfig] = useState({ name: 'NEXUS_V1', color: NEON_COLORS[1].hex, icon: 'O' as IconType });
  const [currentBgCss, setCurrentBgCss] = useState('bg-[#020617]');
  
  useEffect(() => {
    // Load config and saved level
    const savedP1 = localStorage.getItem('player1_config');
    const maxLevel = parseInt(localStorage.getItem('arcade_level_max') || '1', 10);
    
    if (maxLevel > 1) setStageLevel(maxLevel);

    if (savedP1) setP1Config(JSON.parse(savedP1));
  }, []);

  const getDifficulty = (level: number): Difficulty => {
      if (level <= 10) return 'EASY';
      if (level <= 20) return 'MEDIUM';
      if (level <= 30) return 'HARD';
      if (level <= 50) return 'EXTREME';
      return 'NIGHTMARE';
  };

  const currentDifficulty = getDifficulty(stageLevel);

  // Generate AI Config ensuring no conflicts
  const generateAIConfig = useCallback((level: number, playerColor: string, playerIcon: IconType) => {
      const bgIndex = (level - 1) % BACKGROUNDS.length;
      setCurrentBgCss(BACKGROUNDS[bgIndex].css);

      const availableColors = NEON_COLORS.filter(c => c.hex !== playerColor);
      const randomColor = availableColors[Math.floor(Math.random() * availableColors.length)].hex;

      const availableIcons: IconType[] = ['X', 'O', '1', '0', 'S'];
      const filteredIcons = availableIcons.filter(i => i !== playerIcon);
      const randomIcon = filteredIcons[Math.floor(Math.random() * filteredIcons.length)];

      setAiConfig({
          name: `NEXUS_V${level}`,
          color: randomColor,
          icon: randomIcon
      });
  }, []);

  useEffect(() => {
      if (gameStarted) {
          generateAIConfig(stageLevel, p1Config.color, p1Config.icon);
      }
  }, [stageLevel, gameStarted, p1Config.color, p1Config.icon, generateAIConfig]);

  const createInitialBoard = (level: number): GridCell[][] => {
    const board = Array(GRID_SIZE).fill(null).map((_, y) => 
      Array(GRID_SIZE).fill(null).map((_, x) => ({ 
        id: `${x}-${y}-${level}-${Math.random()}`, x, y, owner: null, powerUp: 'NONE' as PowerUpType, powerUpLife: 0
      }))
    );
    for(let i = 0; i < 4; i++) {
      const rx = Math.floor(Math.random() * GRID_SIZE);
      const ry = Math.floor(Math.random() * GRID_SIZE);
      board[ry][rx].powerUp = POWER_UP_POOL[Math.floor(Math.random() * POWER_UP_POOL.length)];
      board[ry][rx].powerUpLife = POWER_UP_LIFETIME;
    }
    return board;
  };

  const [gameState, setGameState] = useState<GameState>({
    board: createInitialBoard(1),
    players: {
      BLUE: { hp: INITIAL_HP, shield: false, critActive: false, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
      RED: { hp: INITIAL_HP, shield: false, critActive: false, color: aiConfig.color, name: aiConfig.name, icon: aiConfig.icon }
    },
    currentPlayer: 'BLUE',
    isGameOver: false,
    isSuddenDeath: initialSuddenDeath,
    winner: null,
    turnTimer: TURN_TIME,
    matchTimer: initialSuddenDeath ? 0 : MATCH_TIME,
    stageColor: NEON_COLORS[Math.floor(Math.random() * 8)].hex,
    stageLevel: 1
  });

  // Sync state when config changes (start of game/level)
  useEffect(() => {
     if (!gameState.isGameOver) {
         setGameState(prev => ({
             ...prev,
             players: {
                 BLUE: { ...prev.players.BLUE, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
                 RED: { ...prev.players.RED, color: aiConfig.color, name: aiConfig.name, icon: aiConfig.icon }
             }
         }));
     }
  }, [p1Config, aiConfig, gameState.isGameOver]);

  // Handle Win Condition & Unlocks
  useEffect(() => {
    if (gameState.isGameOver && gameState.winner === 'BLUE') {
        let msg = '';
        
        const currentMax = parseInt(localStorage.getItem('arcade_level_max') || '0', 10);
        if (stageLevel > currentMax) {
            localStorage.setItem('arcade_level_max', stageLevel.toString());
        }

        const matches = parseInt(localStorage.getItem('matches_played') || '0', 10);
        localStorage.setItem('matches_played', (matches + 1).toString());

        const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if (stageLevel <= ALPHABET.length) {
            const letter = ALPHABET[stageLevel - 1];
            const unlockedIcons = JSON.parse(localStorage.getItem('unlocked_icons') || '[]');
            if (!unlockedIcons.includes(letter)) {
                unlockedIcons.push(letter);
                localStorage.setItem('unlocked_icons', JSON.stringify(unlockedIcons));
                msg = `NEW ICON: '${letter}' UNLOCKED`;
            }
        }

        if (!msg && stageLevel % 3 === 0) {
            const unlocked = JSON.parse(localStorage.getItem('unlocked_colors') || '[]');
            const lockedColors = NEON_COLORS.filter(c => c.locked && !unlocked.includes(c.hex));
            
            if (lockedColors.length > 0) {
                const randomColor = lockedColors[Math.floor(Math.random() * lockedColors.length)];
                unlocked.push(randomColor.hex);
                localStorage.setItem('unlocked_colors', JSON.stringify(unlocked));
                msg = `NEW COLOR: ${randomColor.name} UNLOCKED`;
            }
        }

        if (msg) setUnlockMessage(msg);
    }
  }, [gameState.isGameOver, gameState.winner, stageLevel]);

  const timerRef = useRef<number | null>(null);
  const matchTimerRef = useRef<number | null>(null);
  const suddenDeathRef = useRef<number | null>(null);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (isPaused || !gameStarted) return;
    setGameState(prev => ({ ...prev, turnTimer: TURN_TIME }));
    
    timerRef.current = window.setInterval(() => {
      setGameState(prev => {
        if (prev.turnTimer <= 0) {
          return { ...prev, currentPlayer: prev.currentPlayer === 'BLUE' ? 'RED' : 'BLUE', turnTimer: TURN_TIME };
        }
        return { ...prev, turnTimer: prev.turnTimer - 1 };
      });
    }, 1000);
  }, [isPaused, gameStarted]);

  const handleRestart = () => {
    generateAIConfig(stageLevel, p1Config.color, p1Config.icon);
    
    setGameState({
      board: createInitialBoard(stageLevel),
      players: {
        BLUE: { hp: INITIAL_HP, shield: false, critActive: false, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
        RED: { hp: INITIAL_HP, shield: false, critActive: false, color: aiConfig.color, name: aiConfig.name, icon: aiConfig.icon }
      },
      currentPlayer: 'BLUE',
      isGameOver: false,
      isSuddenDeath: initialSuddenDeath,
      winner: null,
      turnTimer: TURN_TIME,
      matchTimer: initialSuddenDeath ? 0 : MATCH_TIME,
      stageColor: NEON_COLORS[Math.floor(Math.random() * 8)].hex,
      stageLevel: stageLevel
    });
    setIsPaused(false);
    setUnlockMessage(null);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !gameState.isGameOver && gameStarted) setIsPaused(p => !p);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameState.isGameOver, gameStarted]);

  useEffect(() => {
    if (!gameState.isGameOver && !gameState.isSuddenDeath && !isPaused && gameStarted) {
      matchTimerRef.current = window.setInterval(() => {
        setGameState(prev => {
          if (prev.matchTimer <= 1) {
            clearInterval(matchTimerRef.current!);
            return { ...prev, matchTimer: 0, isSuddenDeath: true };
          }
          return { ...prev, matchTimer: prev.matchTimer - 1 };
        });
      }, 1000);
    }
    return () => { if (matchTimerRef.current) clearInterval(matchTimerRef.current); };
  }, [gameState.isGameOver, gameState.isSuddenDeath, isPaused, gameStarted]);

  useEffect(() => {
    if (!gameState.isGameOver && !gameState.isSuddenDeath && !isPaused && gameStarted) {
      startTimer();
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [gameState.isGameOver, gameState.currentPlayer, gameState.isSuddenDeath, startTimer, isPaused, gameStarted]);

  useEffect(() => {
    if (gameState.isSuddenDeath && !gameState.isGameOver && !isPaused && gameStarted) {
      suddenDeathRef.current = window.setInterval(() => {
        setGameState(prev => {
          const newPlayers = { ...prev.players };
          newPlayers.BLUE.hp = Math.max(0, newPlayers.BLUE.hp - 1);
          newPlayers.RED.hp = Math.max(0, newPlayers.RED.hp - 1);
          let winner: Player | null = null;
          let isGameOver = false;
          if (newPlayers.BLUE.hp <= 0 && newPlayers.RED.hp <= 0) {
            winner = prev.players.BLUE.hp > prev.players.RED.hp ? 'BLUE' : 'RED';
            isGameOver = true;
          } else if (newPlayers.BLUE.hp <= 0) { 
            winner = 'RED'; isGameOver = true; 
          } else if (newPlayers.RED.hp <= 0) { 
            winner = 'BLUE'; isGameOver = true; 
          }
          return { ...prev, players: newPlayers, winner, isGameOver };
        });
      }, 2000); // 1 LP per 2 seconds
    }
    return () => { if (suddenDeathRef.current) clearInterval(suddenDeathRef.current); };
  }, [gameState.isSuddenDeath, gameState.isGameOver, isPaused, gameStarted]);

  const addDamageIndicator = (value: number, x: number, y: number, color: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setDamageIndicators(prev => [...prev, { id, value, x, y, color }]);
    setTimeout(() => {
      setDamageIndicators(prev => prev.filter(di => di.id !== id));
    }, 1000);
  };

  const processMove = (x: number, y: number, player: Player) => {
    if (isPaused) return;
    const opponent = player === 'BLUE' ? 'RED' : 'BLUE';
    
    setGameState(prev => {
      let newBoard: GridCell[][] = JSON.parse(JSON.stringify(prev.board));
      const newPlayers = JSON.parse(JSON.stringify(prev.players));
      const cell = newBoard[y][x];
      cell.owner = player;

      let damage = 20;
      const matchedCells: {x: number, y: number}[] = [];

      const checkMatch = (dx: number, dy: number) => {
        const line = [{x, y}];
        let nx = x - dx, ny = y - dy;
        while(nx >= 0 && nx < GRID_SIZE && ny >= 0 && ny < GRID_SIZE && newBoard[ny][nx].owner === player) {
          line.push({x: nx, y: ny}); nx -= dx; ny -= dy;
        }
        nx = x + dx; ny = y + dy;
        while(nx >= 0 && nx < GRID_SIZE && ny >= 0 && ny < GRID_SIZE && newBoard[ny][nx].owner === player) {
          line.push({x: nx, y: ny}); nx += dx; ny += dy;
        }
        return line.length >= 3 ? line : null;
      };

      const matches = [checkMatch(1, 0), checkMatch(0, 1), checkMatch(1, 1), checkMatch(1, -1)];
      matches.forEach(m => m && matchedCells.push(...m));

      if (matchedCells.length > 0) {
        const uniqueMatches = Array.from(new Set(matchedCells.map(c => `${c.x},${c.y}`)))
          .map(s => {
            const [mx, my] = s.split(',').map(Number);
            return {x: mx, y: my};
          });

        uniqueMatches.forEach(p => {
          const pu = newBoard[p.y][p.x].powerUp;
          if (pu === 'FIRE') damage += 25;
          if (pu === 'LIGHTNING') damage += 15;
          if (pu === 'HEAL') newPlayers[player].hp = Math.min(200, newPlayers[player].hp + 20);
          if (pu === 'SHIELD' && !newPlayers[player].shield) newPlayers[player].shield = true;
          if (pu === 'CRIT' && !newPlayers[player].critActive) newPlayers[player].critActive = true;
          newBoard[p.y][p.x].owner = null;
          newBoard[p.y][p.x].powerUp = 'NONE';
          newBoard[p.y][p.x].powerUpLife = 0;
        });

        if (newPlayers[player].critActive) { damage *= 2; newPlayers[player].critActive = false; }
        if (newPlayers[opponent].shield) { newPlayers[opponent].shield = false; damage = 0; }
        
        newPlayers[opponent].hp = Math.max(0, newPlayers[opponent].hp - damage);
        if (damage > 0) addDamageIndicator(damage, x, y, prev.players[player].color);
      }

      newBoard = newBoard.map(row => row.map(c => {
        if (c.powerUp !== 'NONE' && !c.owner) {
          const newLife = (c.powerUpLife || 0) - 1;
          if (newLife <= 0) return { ...c, powerUp: 'NONE' as PowerUpType, powerUpLife: 0 };
          return { ...c, powerUpLife: newLife };
        }
        return c;
      }));

      let activePowerUps = 0;
      const emptyCells: {x: number, y: number}[] = [];
      newBoard.forEach(row => row.forEach(c => {
        if (c.powerUp !== 'NONE') activePowerUps++;
        if (c.powerUp === 'NONE' && !c.owner) emptyCells.push({ x: c.x, y: c.y });
      }));

      if (activePowerUps < MAX_POWER_UPS && emptyCells.length > 0) {
        const countToSpawn = Math.min(2, MAX_POWER_UPS - activePowerUps);
        for(let i = 0; i < countToSpawn; i++) {
            if (emptyCells.length === 0) break;
            const idx = Math.floor(Math.random() * emptyCells.length);
            const { x: sx, y: sy } = emptyCells.splice(idx, 1)[0];
            newBoard[sy][sx].powerUp = POWER_UP_POOL[Math.floor(Math.random() * POWER_UP_POOL.length)];
            newBoard[sy][sx].powerUpLife = POWER_UP_LIFETIME;
        }
      }

      const isFull = newBoard.every((r: GridCell[]) => r.every((c: GridCell) => c.owner !== null));
      let isGameOver = newPlayers.BLUE.hp <= 0 || newPlayers.RED.hp <= 0 || isFull;
      let winner: Player | null = isGameOver ? (newPlayers.BLUE.hp <= 0 ? 'RED' : 'BLUE') : null;

      return {
        ...prev,
        board: newBoard,
        players: newPlayers,
        currentPlayer: opponent,
        isGameOver,
        winner,
        turnTimer: TURN_TIME
      };
    });
  };

  const handleCellClick = (x: number, y: number) => {
    if (gameState.isGameOver || gameState.board[y][x].owner || gameState.currentPlayer !== 'BLUE' || isPaused || !gameStarted) return;
    processMove(x, y, 'BLUE');
  };

  // Improved AI Logic with Difficulty
  useEffect(() => {
    if (gameState.currentPlayer === 'RED' && !gameState.isGameOver && !isPaused && gameStarted) {
      
      let intelligenceCore = 0.2;
      let baseThinkTime = 1500;

      if (currentDifficulty === 'MEDIUM') {
        intelligenceCore = 0.5;
        baseThinkTime = 1200;
      } else if (currentDifficulty === 'HARD') {
        intelligenceCore = 0.8;
        baseThinkTime = 800;
      } else if (currentDifficulty === 'EXTREME' || currentDifficulty === 'NIGHTMARE') {
        intelligenceCore = 0.95;
        baseThinkTime = 400;
      }

      const thinkTime = Math.max(300, baseThinkTime - (stageLevel * 5)); 
      
      const timer = setTimeout(() => {
        const empties: {x: number, y: number}[] = [];
        gameState.board.forEach((row, y) => row.forEach((cell, x) => {
          if (!cell.owner) empties.push({ x, y });
        }));

        if (empties.length > 0) {
          let chosenMove = empties[Math.floor(Math.random() * empties.length)];
          
          if (Math.random() < intelligenceCore) {
            for (const move of empties) {
              if (checkSimulatedMatch(move.x, move.y, 'RED')) {
                chosenMove = move;
                processMove(chosenMove.x, chosenMove.y, 'RED');
                return;
              }
            }

            for (const move of empties) {
              if (checkSimulatedMatch(move.x, move.y, 'BLUE')) {
                chosenMove = move;
                processMove(chosenMove.x, chosenMove.y, 'RED');
                return;
              }
            }

            if (currentDifficulty !== 'EASY') {
                const powerUpMoves = empties.filter(m => gameState.board[m.y][m.x].powerUp !== 'NONE');
                if (powerUpMoves.length > 0) {
                  chosenMove = powerUpMoves[Math.floor(Math.random() * powerUpMoves.length)];
                }
            }
          }
          
          processMove(chosenMove.x, chosenMove.y, 'RED');
        }
      }, thinkTime);
      return () => clearTimeout(timer);
    }
  }, [gameState.currentPlayer, gameState.isGameOver, stageLevel, gameState.board, isPaused, gameStarted, currentDifficulty]);

  // Helper for AI to check if a move creates a match
  const checkSimulatedMatch = (x: number, y: number, p: Player): boolean => {
    const tempBoard = JSON.parse(JSON.stringify(gameState.board));
    tempBoard[y][x].owner = p;
    
    const checkLine = (dx: number, dy: number) => {
      let count = 1;
      let nx = x + dx, ny = y + dy;
      while(nx>=0 && nx<GRID_SIZE && ny>=0 && ny<GRID_SIZE && tempBoard[ny][nx].owner === p) { count++; nx+=dx; ny+=dy; }
      nx = x - dx; ny = y - dy;
      while(nx>=0 && nx<GRID_SIZE && ny>=0 && ny<GRID_SIZE && tempBoard[ny][nx].owner === p) { count++; nx-=dx; ny-=dy; }
      return count >= 3;
    };
    
    return checkLine(1,0) || checkLine(0,1) || checkLine(1,1) || checkLine(1,-1);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const nextLevel = () => {
    const newLevel = stageLevel + 1;
    setStageLevel(newLevel);
    generateAIConfig(newLevel, p1Config.color, p1Config.icon); 
    
    setGameState({
      board: createInitialBoard(newLevel),
      players: {
        BLUE: { hp: INITIAL_HP, shield: false, critActive: false, color: p1Config.color, name: p1Config.name, icon: p1Config.icon },
        RED: { hp: INITIAL_HP, shield: false, critActive: false, color: aiConfig.color, name: aiConfig.name, icon: aiConfig.icon }
      },
      currentPlayer: 'BLUE',
      isGameOver: false,
      isSuddenDeath: gameState.isSuddenDeath,
      winner: null,
      turnTimer: TURN_TIME,
      matchTimer: gameState.isSuddenDeath ? 0 : MATCH_TIME,
      stageColor: NEON_COLORS[Math.floor(Math.random() * 8)].hex,
      stageLevel: newLevel
    });
    setUnlockMessage(null);
  };

  // Briefing Screen
  if (!gameStarted) {
    return (
      <div className={`min-h-screen ${currentBgCss} p-8 font-mono relative overflow-hidden flex flex-col items-center justify-center`}>
        <div className="absolute inset-0 opacity-10 pointer-events-none grid-bg" />
        <motion.div 
            initial={{ opacity: 0, scale: 0.9 }} 
            animate={{ opacity: 1, scale: 1 }} 
            className="max-w-xl w-full relative z-10 bg-slate-900/60 p-12 rounded-[40px] border border-white/10 backdrop-blur-3xl shimmer-effect text-center space-y-12"
        >
           <div>
             <h1 className="text-4xl md:text-5xl font-black italic text-white mb-2 tracking-tighter" style={{ textShadow: '0 0 20px rgba(255,255,255,0.3)' }}>MISSION BRIEFING</h1>
             <div className="h-1 w-24 bg-cyan-500 mx-auto rounded-full" />
           </div>

           <div className="grid grid-cols-2 gap-8 text-left">
               <div>
                   <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">TARGET LEVEL</div>
                   <div className="text-4xl font-black text-white">{stageLevel}</div>
               </div>
               <div>
                   <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">THREAT CLASS</div>
                   <div className={`text-4xl font-black italic ${
                       currentDifficulty === 'EASY' ? 'text-green-400' :
                       currentDifficulty === 'MEDIUM' ? 'text-yellow-400' :
                       currentDifficulty === 'HARD' ? 'text-orange-500' :
                       'text-red-600'
                   }`}>{currentDifficulty}</div>
               </div>
           </div>

           <div className="p-4 bg-slate-800/50 rounded-2xl border border-white/5 text-left flex items-center gap-4">
                <BrainCircuit className="text-cyan-400" size={24} />
                <div>
                    <div className="text-xs font-bold text-white">OPPONENT: {aiConfig.name}</div>
                    <div className="text-[10px] text-slate-400">Adaptive AI / Neural Network V{Math.floor(stageLevel/10)+1}.0</div>
                </div>
           </div>

           <button 
                onClick={() => setGameStarted(true)}
                className={`w-full py-6 bg-white text-slate-950 font-black italic text-2xl rounded-3xl transition-all shadow-lg hover:bg-cyan-400 flex items-center justify-center gap-3`}
           >
                DEPLOY TO GRID <ArrowRight />
           </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${currentBgCss} p-4 md:p-8 font-mono relative overflow-hidden transition-all duration-1000`}>
      <div className="absolute inset-0 opacity-10 pointer-events-none grid-bg" />
      <PauseMenu isOpen={isPaused} onClose={() => setIsPaused(false)} onRestart={handleRestart} />
      
      {/* HUD Bar */}
      <div className="fixed top-[max(1rem,env(safe-area-inset-top))] inset-x-0 px-4 md:px-8 flex flex-nowrap justify-between items-center z-50 w-full gap-2">
        <button onClick={() => setIsPaused(true)} className="flex-shrink-0 p-2 md:p-3 bg-slate-900/50 border border-white/5 rounded-xl text-slate-500 hover:text-white transition-all flex items-center gap-2">
          <Menu size={18} /> <span className="hidden md:inline font-black text-[10px] uppercase tracking-widest">PAUSE</span>
        </button>
        
        <div className="flex-shrink flex flex-col items-center mx-1 md:mx-4 overflow-hidden">
             <div className="flex items-center gap-4 md:gap-6 px-2 md:px-8 py-1.5 md:py-3 bg-slate-900/80 border border-white/5 rounded-full backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.1)]">
                <div className="flex flex-col items-center border-r border-white/10 pr-2 md:pr-6">
                    <div className="hidden md:flex items-center gap-2 mb-1">
                        <Cpu size={12} className="text-cyan-400" />
                        <span className="text-[8px] text-slate-500 uppercase tracking-widest">UNIT</span>
                    </div>
                    <span className="text-sm md:text-xl font-black text-white">{stageLevel}/70</span>
                </div>
                <div className="flex flex-col items-center border-r border-white/10 pr-2 md:pr-6">
                    <span className="text-[6px] md:text-[8px] text-slate-500 uppercase tracking-widest mb-1">SYNC</span>
                    <motion.span key={gameState.turnTimer} className={`text-sm md:text-xl font-black italic ${gameState.turnTimer <= 2 ? 'text-red-500' : 'text-white'}`}>0{gameState.turnTimer}</motion.span>
                </div>
                <div className="flex flex-col items-center">
                    <span className="text-[6px] md:text-[8px] text-slate-500 uppercase tracking-widest mb-1">CORE</span>
                    <div className="flex items-center gap-1 md:gap-2">
                        <Clock size={10} className={gameState.matchTimer < 60 ? 'text-red-500 animate-pulse' : 'text-cyan-400'} />
                        <span className={`text-sm md:text-xl font-black italic ${gameState.matchTimer < 60 ? 'text-red-500' : 'text-cyan-400'}`}>{formatTime(gameState.matchTimer)}</span>
                    </div>
                </div>
             </div>
          </div>

          <button onClick={handleRestart} className="flex-shrink-0 p-2 md:p-3 bg-slate-900/50 border border-white/5 rounded-xl text-slate-500 hover:text-white transition-all">
              <RotateCcw size={16} />
          </button>
        </div>

      {/* HUD Overlays */}
      <div className="fixed top-[calc(5rem+env(safe-area-inset-top))] left-2 md:left-8 z-40 pointer-events-none">
        <GameHUD player={gameState.players.BLUE} side="left" isActive={gameState.currentPlayer === 'BLUE'} isSuddenDeath={gameState.isSuddenDeath} />
      </div>
      <div className="fixed top-[calc(5rem+env(safe-area-inset-top))] right-2 md:right-8 z-40 pointer-events-none text-right">
        <GameHUD player={gameState.players.RED} side="right" isActive={gameState.currentPlayer === 'RED'} isSuddenDeath={gameState.isSuddenDeath} />
      </div>

      <div className="fixed bottom-8 right-8 z-40 bg-slate-900/80 p-4 rounded-2xl border border-red-500/30 backdrop-blur-md flex items-center gap-4 hidden md:flex">
        <motion.div
          animate={{ scale: [1, 1.2, 1], rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-red-500"
        >
          <BrainCircuit size={24} />
        </motion.div>
        <div>
          <div className="text-[10px] text-slate-500 uppercase tracking-widest font-black">AI_CORE_SYNC</div>
          <div className="text-[10px] text-white font-bold">{currentDifficulty} MODE</div>
        </div>
      </div>

      <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
        <AnimatePresence>
          {damageIndicators.map(di => (
            <motion.div
              key={di.id}
              initial={{ opacity: 0, y: 0, scale: 0.5 }}
              animate={{ opacity: 1, y: -100, scale: 1.5 }}
              exit={{ opacity: 0 }}
              className="absolute font-black text-2xl drop-shadow-[0_0_10px_rgba(0,0,0,0.5)]"
              style={{ 
                left: `${(di.x / GRID_SIZE) * 100}%`, 
                top: `${(di.y / GRID_SIZE) * 100}%`,
                color: di.color,
                textShadow: `0 0 10px ${di.color}`
              }}
            >
              -{di.value}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {gameState.isSuddenDeath && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 pointer-events-none z-0">
            <div className="absolute bottom-0 inset-x-0 h-[60vh] bg-gradient-to-t from-red-600/30 to-transparent" />
            <motion.div 
              animate={{ opacity: [0.05, 0.2, 0.05] }}
              transition={{ duration: 0.15, repeat: Infinity }}
              className="absolute inset-0 border-[20px] border-red-600/10 pointer-events-none" 
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto flex flex-col h-full gap-4 md:gap-12 relative z-10 pt-32 md:pt-36">
        <div className="w-full max-w-[500px] mx-auto flex-1 flex flex-col justify-center">
            <GameGrid 
              board={gameState.board} 
              onCellClick={handleCellClick} 
              currentPlayer={gameState.currentPlayer} 
              playerColors={{ BLUE: gameState.players.BLUE.color, RED: gameState.players.RED.color }}
              playerIcons={{ BLUE: gameState.players.BLUE.icon, RED: gameState.players.RED.icon }}
              stageColor={gameState.isSuddenDeath ? '#ef4444' : gameState.stageColor}
            />
        </div>

        <div className="mt-auto text-center py-4">
          <AnimatePresence mode="wait">
            {gameState.isSuddenDeath ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }} 
                animate={{ opacity: 1, scale: 1 }} 
                className="inline-flex items-center gap-2 px-6 md:px-8 py-2 md:py-3 bg-red-600/20 border-2 border-red-500 rounded-full shadow-[0_0_30px_rgba(220,38,38,0.5)]"
              >
                <Flame size={16} className="text-red-500 animate-bounce" />
                <span className="text-red-400 text-[8px] md:text-xs font-black uppercase tracking-[0.2em] flex items-center gap-1">
                  SUDDEN_DEATH_ENGAGED
                </span>
              </motion.div>
            ) : (
               <span className="text-[7px] md:text-[10px] text-slate-700 font-black tracking-[0.5em] md:tracking-[1em] uppercase opacity-40">Neural_Bridge_Active // Sector_Locked</span>
            )}
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {unlockMessage && (
            <motion.div 
                initial={{ opacity: 0, scale: 0.8 }} 
                animate={{ opacity: 1, scale: 1 }} 
                exit={{ opacity: 0 }}
                className="fixed bottom-20 left-0 right-0 z-50 flex justify-center pointer-events-none"
            >
                <div className="bg-slate-900 border-2 border-amber-400 text-white px-8 py-4 rounded-full flex items-center gap-4 shadow-[0_0_30px_rgba(251,191,36,0.5)]">
                    <Lock size={24} className="text-amber-400" />
                    <div>
                        <div className="text-xs font-black text-amber-400 uppercase tracking-widest">System Override</div>
                        <div className="text-lg font-bold">{unlockMessage}</div>
                    </div>
                </div>
            </motion.div>
        )}

        {gameState.isGameOver && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/95 backdrop-blur-2xl p-6 shimmer-effect">
            <motion.div initial={{ scale: 0.8, opacity: 0, y: 30 }} animate={{ scale: 1, opacity: 1, y: 0 }} className="text-center space-y-8 md:space-y-12 max-w-lg relative z-10">
              {gameState.winner === 'BLUE' ? (
                <>
                  <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 2, repeat: Infinity }}>
                    <Target size={80} className="mx-auto text-cyan-400 drop-shadow-[0_0_20px_#22d3ee]" />
                  </motion.div>
                  <h2 className="text-4xl md:text-6xl font-black italic text-white tracking-tighter uppercase mb-4" style={{ textShadow: '0 0 30px rgba(34,211,238,0.5)' }}>Sector_Unlocked</h2>
                  <div className="flex flex-col gap-4">
                    <button 
                      onClick={nextLevel} 
                      className="w-full py-6 bg-cyan-500 text-slate-950 font-black italic text-xl rounded-2xl hover:bg-white transition-all uppercase flex items-center justify-center gap-3 group"
                    >
                      ADVANCE_PROTOCOL <ArrowRight className="group-hover:translate-x-2 transition-transform" />
                    </button>
                    <button 
                      onClick={() => navigate('/')} 
                      className="w-full py-6 bg-slate-900 border-2 border-white/10 text-white font-black italic text-xl rounded-2xl hover:border-white transition-all uppercase flex items-center justify-center gap-3"
                    >
                      <Home /> HOME_BASE
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 0.5, repeat: Infinity }}>
                    <Zap size={80} className="mx-auto text-red-500 drop-shadow-[0_0_20px_#ef4444]" />
                  </motion.div>
                  <h2 className="text-4xl md:text-6xl font-black italic text-white tracking-tighter uppercase mb-4" style={{ textShadow: '0 0 30px rgba(239,68,68,0.5)' }}>Core_Terminated</h2>
                  <div className="flex flex-col gap-4">
                    <button 
                      onClick={() => window.location.reload()} 
                      className="w-full py-6 bg-red-600 text-white font-black italic text-xl rounded-2xl hover:bg-white hover:text-red-600 transition-all uppercase flex items-center justify-center gap-3 group"
                    >
                      <RotateCcw className="group-hover:rotate-180 transition-transform duration-500" /> REBOOT_SYSTEM
                    </button>
                    <button 
                      onClick={() => navigate('/')} 
                      className="w-full py-6 bg-slate-900 border-2 border-white/10 text-white font-black italic text-xl rounded-2xl hover:border-white transition-all uppercase flex items-center justify-center gap-3"
                    >
                      <Home /> HOME_BASE
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ArcadeMode;
