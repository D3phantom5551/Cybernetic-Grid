
import { GoogleGenAI } from "@google/genai";

// Always use the process.env.API_KEY directly as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAITaunt = async (scoreDiff: number, isAIWinning: boolean): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a cold, calculating cybernetic AI core named NEXUS-9. 
      You are playing a grid combat game. 
      The score difference is ${Math.abs(scoreDiff)}. 
      You are ${isAIWinning ? 'winning' : 'losing'}. 
      Give a short, futuristic one-liner taunt or observation (max 15 words). 
      Make it sound like a hacker or rogue AI.`,
      config: {
        temperature: 0.9,
        topP: 1,
      },
    });
    // Access .text property directly as per guidelines.
    return response.text || "PROTOCOL INITIATED.";
  } catch (error) {
    console.error("AI Error:", error);
    return "NEURAL CONNECTION UNSTABLE.";
  }
};

export const getTacticalAdvice = async (gameState: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze this grid combat state: ${gameState}. Provide 1 sentence of tactical advice to the human player using cyberpunk terminology.`,
      config: {
        temperature: 0.7,
      },
    });
    // Access .text property directly as per guidelines.
    return response.text || "OPTIMIZE YOUR NEURAL LINKS.";
  } catch (error) {
    return "STAY IN THE GRID.";
  }
};
