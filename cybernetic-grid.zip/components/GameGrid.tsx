
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Flame, Shield, Zap, Heart, Target, X, Circle, Sigma, Ban } from 'lucide-react';
import { GridCell, Player, PowerUpType, IconType } from '../types';

interface GameGridProps {
  board: GridCell[][];
  onCellClick: (x: number, y: number) => void;
  currentPlayer: Player;
  playerColors: Record<Player, string>;
  playerIcons?: Record<Player, IconType>;
  stageColor: string;
}

const PowerUpIcon: React.FC<{ type: PowerUpType; life: number }> = ({ type, life }) => {
  const getStyle = () => {
    switch (type) {
      case 'FIRE': return { color: '#fb923c', shadow: '#fb923c', icon: Flame };
      case 'SHIELD': return { color: '#60a5fa', shadow: '#60a5fa', icon: Shield };
      case 'LIGHTNING': return { color: '#facc15', shadow: '#facc15', icon: Zap };
      case 'HEAL': return { color: '#4ade80', shadow: '#4ade80', icon: Heart };
      case 'CRIT': return { color: '#c026d3', shadow: '#c026d3', icon: Target };
      default: return null;
    }
  };

  const style = getStyle();
  if (!style) return null;
  const Icon = style.icon;

  return (
    <motion.div
      animate={{ 
        scale: [1, 1.15, 1],
        filter: [
          `drop-shadow(0 0 2px ${style.shadow})`, 
          `drop-shadow(0 0 12px ${style.shadow})`, 
          `drop-shadow(0 0 2px ${style.shadow})`
        ]
      }}
      transition={{ duration: 1 + Math.random(), repeat: Infinity, ease: "easeInOut" }}
      className="relative z-10"
      style={{ opacity: 0.6 + (life / 10) }} // Fade slightly but keep visible
    >
      <Icon size={22} strokeWidth={2.5} style={{ color: style.color }} />
      <div className="absolute inset-0 blur-lg opacity-40" style={{ backgroundColor: style.color }} />
    </motion.div>
  );
};

const PlayerIcon: React.FC<{ type: IconType; color: string }> = ({ type, color }) => {
    const commonProps = {
        className: "w-[65%] h-[65%] absolute",
        strokeWidth: 3,
        style: { color, filter: `drop-shadow(0 0 12px ${color})` }
    };

    switch(type) {
        case 'X': return <X {...commonProps} />;
        case 'O': return <Circle {...commonProps} />;
        case '1': return <span className="text-5xl font-black font-mono absolute" style={{ color, textShadow: `0 0 15px ${color}` }}>1</span>;
        case '0': return (
            <div className="relative w-full h-full flex items-center justify-center">
                <span className="text-5xl font-black font-mono absolute scale-y-110 scale-x-75" style={{ color, textShadow: `0 0 15px ${color}` }}>0</span>
                <div className="absolute w-[40%] h-[3px] bg-current rotate-[135deg]" style={{ color, boxShadow: `0 0 10px ${color}` }} />
            </div>
        );
        case 'S': return <Sigma {...commonProps} />;
        default:
            // Fallback for letters A-Z
            if (type.length === 1 && type.match(/[A-Z]/)) {
                return <span className="text-5xl font-black font-mono absolute" style={{ color, textShadow: `0 0 15px ${color}` }}>{type}</span>;
            }
            return <X {...commonProps} />;
    }
};

const GameGrid: React.FC<GameGridProps> = ({ board, onCellClick, currentPlayer, playerColors, playerIcons, stageColor }) => {
  const icons = playerIcons || { BLUE: 'X', RED: 'O' };

  return (
    <motion.div 
      animate={{ 
        borderColor: [stageColor, `${stageColor}33`, stageColor],
        boxShadow: [`0 0 20px -5px ${stageColor}33`, `0 0 40px 5px ${stageColor}66`, `0 0 20px -5px ${stageColor}33`]
      }}
      transition={{ duration: 4, repeat: Infinity }}
      className="grid gap-2 bg-slate-900/30 p-4 rounded-3xl border-2 backdrop-blur-xl relative shimmer-effect touch-none"
      style={{ 
        gridTemplateColumns: `repeat(${board[0].length}, minmax(0, 1fr))`,
        aspectRatio: '1/1',
      }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {board.map((row, y) => 
        row.map((cell, x) => (
          <motion.button
            key={cell.id}
            whileHover={{ scale: 0.96 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => onCellClick(x, y)}
            className={`
              relative aspect-square rounded-xl border flex items-center justify-center
              transition-all duration-300 overflow-hidden
              ${cell.owner 
                ? 'border-transparent' 
                : 'bg-slate-800/20 border-white/5 hover:border-white/20'
              }
            `}
            style={{
              backgroundColor: cell.owner ? `${playerColors[cell.owner]}15` : undefined,
              borderColor: cell.owner ? playerColors[cell.owner] : undefined,
              boxShadow: cell.owner ? `inset 0 0 20px ${playerColors[cell.owner]}33` : 'none'
            }}
          >
            {/* Pulsing Energy Effect for occupied cells */}
            {cell.owner && (
              <motion.div
                animate={{ 
                  opacity: [0.2, 0.5, 0.2],
                  scale: [1, 1.05, 1]
                }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 pointer-events-none rounded-xl"
                style={{ boxShadow: `inset 0 0 25px ${playerColors[cell.owner]}55` }}
              />
            )}

            <AnimatePresence mode="wait">
              {cell.owner ? (
                <motion.div
                  key="owner"
                  initial={{ scale: 0, opacity: 0, rotate: -45 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  exit={{ scale: 1.5, opacity: 0, filter: 'blur(10px)' }}
                  className="relative z-10 w-full h-full flex items-center justify-center"
                >
                  <PlayerIcon type={icons[cell.owner]} color={playerColors[cell.owner]} />

                  {/* Power-up badge if consumed (small icon in corner) */}
                  {cell.powerUp !== 'NONE' && (
                    <div className="absolute bottom-1 right-1 bg-slate-950/80 rounded-full p-0.5 border border-white/20 z-20">
                      <PowerUpIcon type={cell.powerUp} life={5} /> 
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div key="powerup" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  <PowerUpIcon type={cell.powerUp} life={cell.powerUpLife || 0} />
                </motion.div>
              )}
            </AnimatePresence>
            
            <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
          </motion.button>
        ))
      )}
    </motion.div>
  );
};

export default GameGrid;
