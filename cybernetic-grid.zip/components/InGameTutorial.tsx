
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Target, Shield, Info } from 'lucide-react';

interface TutorialStep {
  title: string;
  text: string;
  icon: React.ReactNode;
}

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    title: "NEURAL LINK ESTABLISHED",
    text: "Your objective is to connect 3 nodes of your color. Matching nodes will deal damage to the enemy core and then disappear.",
    icon: <Zap className="text-cyan-400" />
  },
  {
    title: "POWER-UP SEEDING",
    text: "Cells contain power-ups. Match nodes on them to trigger effects: Fire (+25 DMG), Shield (Block 1 hit), or Heal (+20 HP).",
    icon: <Target className="text-fuchsia-400" />
  },
  {
    title: "COMBAT CYCLE",
    text: "You have only 6 seconds per turn. Speed is critical for neural dominance.",
    icon: <Shield className="text-amber-400" />
  }
];

export const InGameTutorial: React.FC = () => {
  const [step, setStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('hasSeenInGameTutorial');
    if (hasSeenTutorial) setIsVisible(false);
  }, []);

  const handleDismiss = () => {
    if (step < TUTORIAL_STEPS.length - 1) {
      setStep(step + 1);
    } else {
      setIsVisible(false);
      localStorage.setItem('hasSeenInGameTutorial', 'true');
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-end justify-center p-8 bg-slate-950/40 backdrop-blur-[2px] pointer-events-none"
        >
          <motion.div 
            initial={{ y: 50 }}
            animate={{ y: 0 }}
            className="max-w-md w-full bg-slate-900 border-2 border-cyan-500/50 p-6 rounded-3xl shadow-[0_0_30px_rgba(34,211,238,0.2)] pointer-events-auto"
          >
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-slate-800 rounded-2xl">
                {TUTORIAL_STEPS[step].icon}
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-black text-white italic mb-1 tracking-widest uppercase">
                  {TUTORIAL_STEPS[step].title}
                </h4>
                <p className="text-[11px] text-slate-400 font-mono leading-relaxed mb-4">
                  {TUTORIAL_STEPS[step].text}
                </p>
                <button 
                  onClick={handleDismiss}
                  className="text-[10px] font-black text-cyan-400 uppercase tracking-widest hover:text-white transition-colors flex items-center gap-2"
                >
                  {step < TUTORIAL_STEPS.length - 1 ? "Next Instruction" : "Acknowledge Protocol"} <Info size={12} />
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
