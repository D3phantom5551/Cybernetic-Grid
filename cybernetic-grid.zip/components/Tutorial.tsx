
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, Zap, Target, Cpu } from 'lucide-react';

interface TutorialProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const Tutorial: React.FC<TutorialProps> = ({ isOpen, onClose, onComplete }) => {
  const [step, setStep] = React.useState(0);

  const steps = [
    {
      title: "Neural Initialization",
      icon: <Zap className="w-12 h-12 text-cyan-400" />,
      content: "Welcome to Cybernetic Grid. You control a neural sequence. Your goal is to dominate the grid by capturing nodes."
    },
    {
      title: "Combat Protocol",
      icon: <Target className="w-12 h-12 text-fuchsia-400" />,
      content: "Place your nodes on empty cells. If you place a node next to an enemy's, you capture their adjacent nodes!"
    },
    {
      title: "Dominance Metric",
      icon: <Cpu className="w-12 h-12 text-purple-400" />,
      content: "The player with the most nodes when the grid is full wins. Watch out for the NEXUS AI, it's highly adaptive."
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-8 max-w-lg w-full relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4">
              <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
                <X />
              </button>
            </div>

            <div className="flex flex-col items-center text-center">
              <motion.div
                key={step}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="mb-6"
              >
                {steps[step].icon}
              </motion.div>
              
              <h3 className="text-2xl font-bold text-cyan-300 mb-4">{steps[step].title}</h3>
              <p className="text-slate-300 font-mono text-sm leading-relaxed mb-8">
                {steps[step].content}
              </p>

              <div className="flex gap-4 w-full">
                {step > 0 && (
                  <button
                    onClick={() => setStep(s => s - 1)}
                    className="flex-1 py-3 px-6 rounded-xl bg-slate-800 text-slate-300 font-bold border border-slate-700 hover:bg-slate-700 transition-colors"
                  >
                    BACK
                  </button>
                )}
                <button
                  onClick={() => {
                    if (step < steps.length - 1) setStep(s => s + 1);
                    else onComplete();
                  }}
                  className="flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold shadow-lg shadow-cyan-500/20 hover:scale-105 transition-transform flex items-center justify-center gap-2"
                >
                  {step < steps.length - 1 ? "CONTINUE" : "INITIATE"}
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default Tutorial;
