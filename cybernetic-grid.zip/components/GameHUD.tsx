
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Target, AlertTriangle, Skull } from 'lucide-react';
import { PlayerState } from '../types';

interface GameHUDProps {
  player: PlayerState;
  side: 'left' | 'right';
  isSuddenDeath: boolean;
  isActive: boolean;
}

const GameHUD: React.FC<GameHUDProps> = ({ player, side, isSuddenDeath, isActive }) => {
  const isLeft = side === 'left';
  
  return (
    <div className={`flex flex-col ${isLeft ? 'items-start text-left' : 'items-end text-right'} w-full max-w-[120px] md:max-w-[240px] transition-all duration-500`}>
      {/* Header Info */}
      <div className="mb-1 md:mb-2 flex items-center gap-1 md:gap-2">
        <span className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">P{isLeft ? '1' : '2'} // {isLeft ? 'HOST' : 'GUEST'}</span>
        <div 
          className={`w-1.5 h-1.5 md:w-2 md:h-2 rounded-full ${isActive ? 'animate-pulse' : 'opacity-20'}`} 
          style={{ backgroundColor: player.color, boxShadow: isActive ? `0 0 8px ${player.color}` : 'none' }} 
        />
      </div>
      
      {/* Player Name */}
      <h3 
        className="text-xs md:text-xl font-black italic mb-1 md:mb-2 uppercase tracking-tighter truncate w-full" 
        style={{ color: player.color, textShadow: isActive ? `0 0 15px ${player.color}66` : 'none' }}
      >
        {player.name}
      </h3>

      {/* HP Number Display */}
      <div className="relative">
         <motion.div 
           className="flex items-baseline gap-1"
         >
            <motion.span 
                key={player.hp}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className={`text-4xl md:text-7xl font-black italic tracking-tighter tabular-nums ${isSuddenDeath ? 'animate-pulse' : ''}`}
                style={{ 
                    color: isSuddenDeath ? '#ef4444' : (player.hp < 50 ? '#ef4444' : player.color),
                    textShadow: `0 0 20px ${isSuddenDeath ? '#ef4444' : player.color}44`
                }}
            >
                {player.hp}
            </motion.span>
            <span className={`text-[10px] md:text-xs font-bold ${isSuddenDeath ? 'text-red-500' : 'text-slate-500'}`}>LP</span>
         </motion.div>
         
         {isSuddenDeath && (
             <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute -bottom-4 md:-bottom-6 flex items-center gap-1 text-red-500"
             >
                 <Skull size={10} className="md:w-3 md:h-3 animate-bounce" />
                 <span className="text-[6px] md:text-[8px] font-black uppercase tracking-widest">Decay Active</span>
             </motion.div>
         )}
      </div>

      {/* Mini Power-up Tray */}
      <div className={`flex items-center gap-1 md:gap-2 mt-2 md:mt-4 w-full ${isLeft ? 'flex-row' : 'flex-row-reverse'}`}>
          <AnimatePresence>
            {player.shield && (
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="p-1 md:p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/30 shadow-[0_0_10px_rgba(59,130,246,0.3)]">
                <Shield size={12} className="md:w-[14px] md:h-[14px] text-blue-400" />
              </motion.div>
            )}
            {player.critActive && (
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="p-1 md:p-1.5 bg-purple-500/10 rounded-lg border border-purple-500/30 shadow-[0_0_10px_rgba(168,85,247,0.3)]">
                <Target size={12} className="md:w-[14px] md:h-[14px] text-purple-400" />
              </motion.div>
            )}
          </AnimatePresence>
      </div>
    </div>
  );
};

export default GameHUD;
