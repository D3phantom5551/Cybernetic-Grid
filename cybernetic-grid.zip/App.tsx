
import React, { useState, useEffect, useRef } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import VSMode from './pages/VSMode';
import ArcadeMode from './pages/ArcadeMode';
import ClassicMode from './pages/ClassicMode';
import Leaderboard from './pages/Leaderboard';
import PlayerProfile from './pages/PlayerProfile';
import TrainingMode from './pages/TrainingMode';

const App: React.FC = () => {
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [customAudioUrl, setCustomAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const defaultUrl = 'https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3';
    audioRef.current = new Audio(customAudioUrl || defaultUrl);
    audioRef.current.loop = true;
    audioRef.current.volume = 0.15;

    if (musicEnabled) {
      audioRef.current.play().catch(e => console.log("Audio play deferred:", e));
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [customAudioUrl]);

  const handleMusicToggle = (enabled: boolean) => {
    setMusicEnabled(enabled);
    if (audioRef.current) {
      if (enabled) {
        audioRef.current.play().catch(() => {});
      } else {
        audioRef.current.pause();
      }
    }
  };

  const handleCustomAudio = (file: File) => {
    const url = URL.createObjectURL(file);
    setCustomAudioUrl(url);
  };

  return (
    <HashRouter>
      <div className="relative min-h-screen">
        <Routes>
          <Route path="/" element={<Home musicEnabled={musicEnabled} onMusicToggle={handleMusicToggle} onCustomAudio={handleCustomAudio} customAudioActive={!!customAudioUrl} />} />
          <Route path="/VSMode" element={<VSMode />} />
          <Route path="/ArcadeMode" element={<ArcadeMode />} />
          <Route path="/ClassicMode" element={<ClassicMode />} />
          <Route path="/Leaderboard" element={<Leaderboard />} />
          <Route path="/PlayerProfile" element={<PlayerProfile />} />
          <Route path="/TrainingMode" element={<TrainingMode />} />
        </Routes>
      </div>
    </HashRouter>
  );
};

export default App;
